"""check hooks — the tracked hook corpus under `tools/hooks/` is armed and every hook runs.

Five questions per entry: `core.hooksPath` points here; the entry is a regular file;
it carries an exec bit; it starts (a `cc-*` hook fails open on unreadable input, any
other parses under `bash -n`); and one naming `--self-test` replays its corpus and
prints `SELF-TEST OK`. Which hooks carry a corpus, and which can block (`exit 2`), is
derived from each hook's text, never a roster. `_*` and `*.local` are excluded and
disclosed. Zero hooks, or zero replays, is a finding. A TIMED line names what each
hook it started cost, slowest first, on a pass and on a fail alike.

TWO ARMINGS, and only one is git's. `core.hooksPath` arms the git hooks and is
verified. A `cc-*` hook is a Claude Code hook that git never execs; what arms it is
a settings file, and whether a harness READ that file depends on the session's
project root. So its registration is COUNTED on a REGISTERED line and never
asserted — the same sentence `check pm` U4 owes the ledger couriers.

No devkit.toml section: `tools/hooks/` is where `install-hooks` writes in every consumer.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import time
from functools import lru_cache
from pathlib import Path

from agentic_sdlc.core import spawn, walk
from agentic_sdlc.core.project import repo_root
from agentic_sdlc.core.walk import Kind, SkipReason, Walk
from agentic_sdlc.repo import vehicle

HOOKS_DIR = 'tools/hooks'
CC_PREFIX = 'cc-'
# A consumer must be able to run the repair; no make target wraps it.
ARM_COMMAND = 'bash tools/setup-hooks.sh'
INSTALL_COMMAND = vehicle.command('install-hooks')

# Every Claude Code hook promises exit 0 and a reason on stderr for this.
UNREADABLE_PAYLOAD = 'not json {{{'
FAIL_OPEN = 0
LABEL_WIDTH = len('NOT EXECUTABLE')

# The marker matters as much as the exit code: an unhandled flag falls through to exit 0.
SELF_TEST_FLAG = '--self-test'
SELF_TEST_OK = 'SELF-TEST OK'
# A non-comment line naming the flag nominates a candidate; the run is the proof.
SELF_TEST_DECL = re.compile(rf'^(?![ \t]*#).*{re.escape(SELF_TEST_FLAG)}',
                            re.MULTILINE)

# A statement-initial `exit 2`, because the couriers name the digit only in prose.
BLOCK_EXIT = 2
BLOCKS_DECL = re.compile(rf'^[ \t]*exit[ \t]+{BLOCK_EXIT}\b', re.MULTILINE)


# --- the OTHER arming, and it is not git's (0.6.0/D6) -------------------------
SETTINGS_FILES = ('.claude/settings.json', '.claude/settings.local.json')


def _commands(node: object) -> list[str]:
    """Every `command` string under a settings file's `hooks` key — never the
    document's text, where an allowlist entry reads as a registration."""
    found: list[str] = []
    if isinstance(node, dict):
        command = node.get('command')
        if isinstance(command, str):
            found.append(command)
        for key, value in node.items():
            if key != 'command':
                found.extend(_commands(value))
    elif isinstance(node, list):
        for item in node:
            found.extend(_commands(item))
    return found


def settings_document(path: Path) -> tuple[dict, str]:
    """(one settings file's top-level table, why it was unread).

    Absent, or a document that is not a table, is `({}, '')`. `preflight`
    reads `permissions` through this, so both readers fail the same way.
    """
    if not path.is_file():
        return {}, ''
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, UnicodeDecodeError) as err:
        return {}, err.__class__.__name__
    except ValueError as err:
        return {}, f'it is not JSON: {err}'
    return (data if isinstance(data, dict) else {}), ''


def settings_commands(path: Path) -> tuple[tuple[str, ...], str]:
    """(the hook commands this one settings file registers, why it was unread).

    Absent is `((), '')` and never a defect: a tree that registers nothing has
    opted out (0.4.0/D5). `check pm`'s courier rules read through this too.
    """
    data, why = settings_document(path)
    return tuple(_commands(data.get('hooks'))), why


def _registered(root: Path, names: list[str]) -> tuple[set[str], str, str]:
    """(which of `names` a settings file registers, where, why unread)."""
    found: set[str] = set()
    where: list[str] = []
    unread: list[str] = []
    for rel in SETTINGS_FILES:
        commands, why = settings_commands(root / rel)
        if why:
            unread.append(f'{rel} could not be read ({why})')
            continue
        here = {name for name in names
                if any(name in command for command in commands)}
        if here:
            found |= here
            where.append(rel)
    return found, ' and '.join(where), '; '.join(unread)


def _arming(root: Path, agent_hooks: list[str]) -> str:
    """What is registered for the `cc-*` half, and what registration is worth.

    Counted, never asserted, and the measurement that ruled it: 0.6.0/D6.
    """
    registered, where, unread = _registered(root, agent_hooks)
    missing = sorted(set(agent_hooks) - registered)
    said = [f'{len(registered)} of {len(agent_hooks)} {CC_PREFIX}hook(s) '
            f'registered in {where}' if registered else
            f'NONE of the {len(agent_hooks)} {CC_PREFIX}hook(s) is registered '
            f'in a settings file in this checkout']
    if missing:
        said.append(f'{", ".join(missing)} registered nowhere here')
    if unread:
        said.append(unread)
    return (f'{"; ".join(said)} — `install-hooks --write-settings` lands the '
            f'block. Registered is not IN FORCE: whether a harness reads that '
            f'file depends on the session\'s project root, so this is counted, '
            f'never asserted')


def _entries(directory: Path) -> Walk:
    """The hook entry points, `Kind.ANY` so a directory or broken symlink is a finding, not a subtraction."""
    return walk.children(directory, Kind.ANY).filter(
        lambda path: not path.name.startswith('_')
        and not path.name.endswith('.local'),
        SkipReason.EXCLUDED_PATH)


def cc_registration(root: Path) -> tuple[list[str], set[str], str, str]:
    """(the `cc-*` hook files on disk, which of them a settings file
    registers, where, why unread) — read as text, nothing started.

    The wiring half of `run()`, for `preflight`, which runs from a SessionStart
    hook and so may not start every hook the way this gate does.
    """
    names = [path.name for path in _entries(root / HOOKS_DIR)
             if path.is_file() and path.name.startswith(CC_PREFIX)]
    return (names, *_registered(root, names))


def _not_a_file(path: Path) -> str:
    """What an entry git cannot exec actually is."""
    if path.is_dir():
        return 'is a directory'
    if path.is_symlink():
        return f'is a symlink to {os.readlink(path)}, which does not resolve'
    if not path.exists():
        return 'does not resolve'
    return 'is not a regular file'


def _hooks_path(root: Path) -> str:
    done = spawn.run(['git', 'config', '--get', 'core.hooksPath'],
                     cwd=root, capture_output=True, text=True)
    return done.stdout.strip() if done.returncode == 0 else ''


def _main_worktree(root: Path) -> Path | None:
    """The main worktree when `root` is a LINKED one, else None. Linked
    worktrees share the common config, and a harness that makes agent
    worktrees (Claude Code does) writes an ABSOLUTE `core.hooksPath` naming
    the main worktree's corpus — armed there, not misdirected."""
    done = spawn.run(['git', 'rev-parse', '--path-format=absolute',
                      '--git-common-dir'], cwd=root, capture_output=True,
                     text=True)
    common = Path(done.stdout.strip()) if done.returncode == 0 else None
    if common is None or common.name != '.git' or common.parent == root:
        return None
    return common.parent


# What runs the corpus: bash runs each hook, and a hook parses its payload
# with python3, or jq where python3 is not on PATH.
INTERPRETERS = ('bash', 'python3')
FALLBACK = 'jq'


@lru_cache(maxsize=1)
def interpreters() -> tuple[str, ...]:
    """Each interpreter the corpus runs under, as `<name> <path> <version>`,
    and which jq is on PATH — a hook replay and this gate are keyed on them
    (review F4). A version that cannot be asked is `unknown`."""
    facts = []
    for name in INTERPRETERS:
        found = shutil.which(name) or ''
        version = ''
        if found:
            try:
                done = spawn.run([found, '--version'], capture_output=True,
                                 text=True)
                said = (done.stdout or done.stderr).strip().splitlines()
                version = said[0] if said else 'unknown'
            except OSError:
                version = 'unknown'
        facts.append(f'{name} {found} {version}')
    facts.append(f'{FALLBACK} {shutil.which(FALLBACK) or ""}')
    return tuple(facts)


def inputs():
    """What this gate reads, for `check all`'s reuse (#98): the corpus, both
    settings files, devkit.toml, and what git and PATH say — the arming, and
    which bash and python3 run the corpus at which version."""
    from agentic_sdlc.core.project import CONFIG_NAME
    from agentic_sdlc.repo.verify.gates import Inputs
    root = repo_root()
    return Inputs(scope=(HOOKS_DIR, CONFIG_NAME), also=SETTINGS_FILES,
                  facts=(_hooks_path(root), str(_main_worktree(root) or ''),
                         *interpreters()))


def _runs(path: Path, root: Path) -> str:
    """'' when the hook started and answered; the finding text when it did not."""
    if path.name.startswith(CC_PREFIX):
        done = spawn.run(['bash', str(path)], input=UNREADABLE_PAYLOAD,
                         text=True, capture_output=True, cwd=root)
        if done.returncode != FAIL_OPEN:
            said = (done.stderr or done.stdout).strip().splitlines()
            return (f'exited {done.returncode} on a payload it cannot read, '
                    f'where every Claude Code hook fails OPEN at '
                    f'{FAIL_OPEN} — it is installed and it stops nothing'
                    + (f': {said[-1]}' if said else ''))
        return ''
    done = spawn.run(['bash', '-n', str(path)], capture_output=True,
                     text=True, cwd=root)
    if done.returncode != 0:
        return f'does not parse: {done.stderr.strip().splitlines()[-1]}'
    return ''


def _source(path: Path) -> str:
    """The hook's text, or '' when unreadable (already a finding from `_runs`)."""
    try:
        return path.read_text(encoding='utf-8', errors='replace')
    except OSError:
        return ''


def _self_test(path: Path, root: Path) -> str:
    """'' when the hook's own corpus replayed clean; the finding text when not.
    Inside `check all`, a replay of these exact bytes that passed is reused
    rather than bought again (#98).
    """
    from agentic_sdlc.repo.verify import gates
    return gates.replay(path, lambda: _replay(path, root))


def _replay(path: Path, root: Path) -> str:
    """The replay itself. `input=''` keeps a hook that reads stdin from
    blocking on a terminal."""
    done = spawn.run(['bash', str(path), SELF_TEST_FLAG], input='',
                     text=True, capture_output=True, cwd=root)
    said = (done.stderr or done.stdout).strip().splitlines()
    tail = f': {said[-1]}' if said else ''
    if done.returncode != 0:
        return (f'fails its own {SELF_TEST_FLAG} corpus (exit '
                f'{done.returncode}){tail}')
    if SELF_TEST_OK not in done.stdout:
        return (f'names {SELF_TEST_FLAG} and does not answer it — exit 0 with '
                f'no {SELF_TEST_OK!r} line, so nothing was replayed and the '
                f'zero it reports is not a pass{tail}')
    return ''


def _timed(spent: dict[str, float]) -> str:
    """Every started hook with its seconds, slowest first; a tie reads by name."""
    ranked = sorted(spent.items(), key=lambda item: (-item[1], item[0]))
    each = ', '.join(f'{name} {seconds:.2f}s' for name, seconds in ranked)
    return (f'{len(ranked)} hook(s), {sum(spent.values()):.2f}s, slowest '
            f'first (start + {SELF_TEST_FLAG}): {each}')


def run() -> int:
    root = repo_root()
    hooks = root / HOOKS_DIR
    findings: list[tuple[str, str]] = []

    configured = _hooks_path(root)
    if not configured:
        findings.append((
            'UNARMED',
            f'core.hooksPath is unset, so git runs nothing under {HOOKS_DIR}/ '
            f'whatever is in it — `{ARM_COMMAND}`'))
    elif Path(os.path.normpath(root / configured)) != hooks and (
            (main := _main_worktree(root)) is not None
            # resolve(): git answers /private/var where the config says /var
            and (root / configured).resolve() == (main / HOOKS_DIR).resolve()):
        # Not a finding, and never silent: git here runs the MAIN worktree's
        # corpus, which may differ from this checkout's copy (rule 11).
        print(f'[check:hooks] note — a linked worktree: core.hooksPath is the '
              f'main worktree\'s {main / HOOKS_DIR}, which is the corpus git '
              f'runs here; the entries below are this checkout\'s {HOOKS_DIR}/')
    elif Path(os.path.normpath(root / configured)) != hooks:
        findings.append((
            'MISDIRECTED',
            f'core.hooksPath is {configured!r} — that is '
            f'{os.path.normpath(root / configured)}, not {hooks} — '
            f'`{ARM_COMMAND}`'))

    if not hooks.is_dir():
        print(f'[check:hooks] FAIL — there is no {HOOKS_DIR}/ directory; '
              f'`{INSTALL_COMMAND}` ships the corpus and '
              f'`{ARM_COMMAND}` arms it')
        return 1
    entries = _entries(hooks)
    census = entries.census(f'hook(s) under {HOOKS_DIR}/')
    if not entries.kept:
        print(f'[check:hooks] FAIL — {census}, so this reports on nothing; '
              f'`{INSTALL_COMMAND}` ships the corpus')
        return 1
    if shutil.which('bash') is None:
        # The corpus is bash, so no bash is the finding, not a caveat.
        print(f'[check:hooks] FAIL — bash is not on PATH, so not one of the '
              f'{census} can run')
        return 1

    ran = parsed = replayed = 0
    agent_hooks: list[str] = []
    # Counted only over hooks that started, like every other number in the verdict.
    blockers = blockers_replayed = 0
    # Seconds per hook this gate STARTED — the probe and the replay together,
    # because both are what this gate spends on it (rule 11: the cost is
    # visible where you stand).
    spent: dict[str, float] = {}
    for path in entries:
        rel = path.relative_to(root)
        if not path.is_file():
            findings.append((
                'NOT A FILE',
                f'{rel} {_not_a_file(path)} — git cannot exec it, so whatever '
                f'guard that name stands for runs nothing; `_`-prefix it if it '
                f'is not a hook — `{ARM_COMMAND}`'))
            continue
        if not os.access(path, os.X_OK):
            findings.append((
                'NOT EXECUTABLE',
                f'{rel} — core.hooksPath skips it in silence — '
                f'`{ARM_COMMAND}`'))
            continue
        started = time.monotonic()
        broken = _runs(path, root)
        spent[path.name] = time.monotonic() - started
        if broken:
            # One finding per hook: a dead hook cannot replay a corpus either.
            findings.append(('DEAD', f'{rel} {broken}'))
            continue
        if path.name.startswith(CC_PREFIX):
            ran += 1
            agent_hooks.append(path.name)
        else:
            parsed += 1
        source = _source(path)
        blocks = bool(BLOCKS_DECL.search(source))
        if blocks:
            blockers += 1
        if SELF_TEST_DECL.search(source):
            replayed += 1
            if blocks:
                blockers_replayed += 1
            started = time.monotonic()
            failed = _self_test(path, root)
            spent[path.name] += time.monotonic() - started
            if failed:
                findings.append(('SELF-TEST', f'{rel} {failed}'))

    if not replayed:
        # An uninstalled corpus and a passing one look identical from here.
        findings.append((
            'NO CORPUS',
            f'not one hook under {HOOKS_DIR}/ declares a {SELF_TEST_FLAG} '
            f'corpus, so nothing was replayed — an uninstalled corpus and a '
            f'passing one print the same word from here'))

    # Spelled in words on the two shapes a bare ratio reads wrong.
    if not blockers:
        covered = f'no hook here can BLOCK at exit {BLOCK_EXIT}'
    elif not blockers_replayed:
        covered = (f'NONE of the {blockers} that can BLOCK (exit {BLOCK_EXIT}) '
                   f'— the replay covers only hooks that always allow')
    else:
        covered = f'{blockers_replayed} of {blockers} that can BLOCK'
    scope = (f'{census}; {ran} fail open on a payload they cannot read, '
             f'{parsed} parse, {replayed} replay their own {SELF_TEST_FLAG} '
             f'corpus, {covered}')
    # NAMED, never asserted (rule 4): a registration is not a hook that ran.
    if agent_hooks:
        print(f'  {"REGISTERED":<{LABEL_WIDTH}} {_arming(root, agent_hooks)}')
    if spent:
        print(f'  {"TIMED":<{LABEL_WIDTH}} {_timed(spent)}')
    if findings:
        for label, said in findings:
            print(f'  {label:<{LABEL_WIDTH}} {said}')
        print(f'[check:hooks] FAIL — {len(findings)} finding(s) across {scope}')
        return 1
    print(f'[check:hooks] PASS — git-armed at {configured}; {scope}')
    return 0
