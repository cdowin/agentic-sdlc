"""driver.py — the engine all four belts run on, and the verb that starts one.

`close story <id>`, `close feature <id>`, `release <version>` and
`adopt <version>` are one machine over four check lists (D12). Every check
prints one line — `ok: <check> — <detail>`, `error: <check>: <what is false>`
or `unverifiable: <check>: <why>` (counts as false) — then: all true → the
grain's status is set to the first state of `[pm.states.<kind>] done`, exit 0;
any false → no status written, exit 1; `--force` → the write anyway and a
ledger `deviation` row naming the false checks. `adopt` is checks only. Exit 2
is a declaration this machine could not read (D11). What the caller does next
is printed as `next:` lines; nothing else is written, moved, pushed or tagged.

A check has THREE answers, not two (0.5.0/D5): `--skip <check> "<why>"` means
the caller ANSWERED it, so it is not asked and the close is clean, and the
judgement is a field on the `disposition` row the WRITE mints, because a close
is an arrival (0.5.0/D6). Only a check named in `[<op>] skippable` may be
skipped, a skip with no reason is refused, and stock declares nothing
skippable, so stock behaviour is unchanged.
"""
from __future__ import annotations

import contextlib
import functools
import io
import sys
from dataclasses import dataclass, replace
from enum import Enum
from pathlib import Path
from typing import Callable, Mapping, Sequence

from agentic_sdlc.core.config import ConfigError
from agentic_sdlc.repo import emit, vehicle
from agentic_sdlc.repo.conveyor import lessons
from agentic_sdlc.repo.pm import inventory, ledger, verdict, vocabulary

# `story` and `feature` are subcommands of `close`, since `agentic-sdlc story`
# would be a second spelling of `pm story`.
CLOSE_VERB = 'close'
# An OPERATION name — a belt's, not a grain kind's; they share a spelling
# because a belt is named for what it closes, and `_wrong_kind` holds one up.
OP_STORY = 'story'
OP_FEATURE = 'feature'
CLOSE_OPERATIONS = (OP_STORY, OP_FEATURE)
OPERATIONS = ('release', 'adopt', *CLOSE_OPERATIONS)
VERBS = ('release', 'adopt', CLOSE_VERB)

# The grain kind each operation writes; '' for the one that writes nothing.
WRITES = {'release': vocabulary.GRAIN_MILESTONE, OP_STORY: vocabulary.GRAIN_STORY,
          OP_FEATURE: vocabulary.GRAIN_FEATURE, 'adopt': ''}

# Segment count, noun and shape of each operation's subject.
SUBJECT = {
    'release': (1, 'version', '<version>'),
    'adopt': (1, 'version', '<version>'),
    # The count only separates a version subject from a grain one.
    OP_STORY: (2, 'story id', '<story-id>'),
    OP_FEATURE: (2, 'feature id', '<feature-id>'),
}

# A milestone id is one path segment; `inventory.segment_is_literal` owns the
# grammar.
MAX_VERSION = 128
MAX_SUBJECT = MAX_VERSION * len(SUBJECT[OP_STORY][2].split('/'))
# How much of a hostile argument is quoted back.
QUOTE_LIMIT = 40

# `ledger.OUTCOMES` does not list it, so the row is minted here with
# `ledger.deviation_row`'s keys.
FORCED = 'forced'

# --- the disposition a caller gives a check (0.5.0/D5) ------------------------
# The flag and how many words it takes: the CHECK and the WHY, in that order,
# positionally, so a reason opening with a dash is still a reason.
SKIP_FLAG = '--skip'
# `close feature <id> --review-record <path>`: the record the checks read, and
# the `reviewed:` stamp the one write carries.
RECORD_FLAG = '--review-record'
SKIP_ARITY = 2

# A skip mints NO ROW OF ITS OWN. The belt collects what the caller answered
# and hands it to the WRITE, which is an arrival, and `ledger.disposition_row`
# carries it as a field on the one row that arrival mints (0.5.0/D6).
# The word an UNVERIFIABLE answer is named by on the line.
UNVERIFIABLE_WORD = 'unverifiable'
# What a checks-only belt says before its first check: it writes nothing
# (D12), whatever the tree holds, so nothing in the line can read as a write
# that a different tree would have made.
NOTHING_RECORDED = ('checks only — this belt sets no status and files no row '
                    'of its own')
ANYWHERE = 'the bump may be tracked as a feature, as a story, or nowhere'


class Truth(Enum):
    """What a check answered; UNVERIFIABLE is "this cannot be decided", not
    "no"."""

    TRUE = 'true'
    FALSE = 'false'
    UNVERIFIABLE = 'unverifiable'


# The word each answer is NAMED by — on the line and in the emitted row, which
# is one fact and therefore one table. A closed vocabulary: a `check.verdict`
# row a consumer cannot key on is a row it has to parse prose out of.
VERDICT_WORDS = {Truth.TRUE: 'ok', Truth.FALSE: 'error',
                 Truth.UNVERIFIABLE: UNVERIFIABLE_WORD}

# What a check that answered no and gave none reports instead: a defect in the
# check, and the sentence the row carries as its `detail` (rule 4).
NO_REASON = ('the check answered no and gave no reason — a defect in the '
             'check, not a fact about the tree')


@dataclass(frozen=True)
class Answer:
    """A check's return: the truth, and the sentence the line prints after
    the check's name."""

    truth: Truth
    detail: str = ''
    names: tuple[str, ...] = ()
    """The grains this answer NAMED, for the checks that name any — the
    blockers `pm ready-for` printed. A lesson recorded against one surfaces
    beside the check that named it, and every other check names none. Read off
    another verb's sentences (`lessons.blockers_named`), a few of which lead
    with a record path or a finding id instead; filtering those would mean
    deciding what an id LOOKS like, and matching is `==` at the reader, so one
    naming no lesson surfaces nothing."""

    @property
    def is_true(self) -> bool:
        return self.truth is Truth.TRUE

    @classmethod
    def yes(cls, detail: str = '') -> 'Answer':
        return cls(Truth.TRUE, detail)

    @classmethod
    def no(cls, detail: str = '') -> 'Answer':
        return cls(Truth.FALSE, detail)

    @classmethod
    def unverifiable(cls, detail: str = '') -> 'Answer':
        return cls(Truth.UNVERIFIABLE, detail)


@dataclass(frozen=True)
class Context:
    """What every check is handed: the checkout, the operation, the subject.
    `record` is the review record `close feature --review-record` names: the
    record checks read it in place of the `reviewed:` pointer."""

    root: Path
    operation: str
    version: str
    record: str = ''


@dataclass(frozen=True)
class Check:
    """One check: a name and a question about the tree; nothing performs
    anything (D12)."""

    name: str
    check: Callable[[Context], Answer]


@dataclass(frozen=True)
class Result:
    """What one run did: `false` names every check not true, `skipped` every
    check the caller answered instead, `written` is the state set or '',
    `refused` is a mid-run `ConfigError`'s sentence (exit 2, D11)."""

    lines: tuple[str, ...]
    false: tuple[str, ...]
    written: str
    exit_code: int
    refused: str = ''
    skipped: tuple[str, ...] = ()


class Shared:
    """The checks a many-id `close story|feature` asks ONCE (#95), and what each
    answered at the first id that asked it. A later id is handed the same
    answer, and its line says so."""

    def __init__(self, names: frozenset[str]):
        self.names = names
        self.answers: dict[str, tuple[str, Answer]] = {}

    def answer(self, name: str, asking: Callable[[], Answer],
               subject: str) -> Answer:
        if name not in self.answers:
            got = asking()
            self.answers[name] = (subject, got)
            return got
        first, got = self.answers[name]
        said = f'asked once for this close, at {first}'
        return replace(got, detail=f'{got.detail} — {said}' if got.detail
                       else said)


def ask(check: Check, ctx: Context) -> Answer:
    """`check.check(ctx)`, with an unexpected exception turned into an
    UNVERIFIABLE answer; `ConfigError` is re-raised because a malformed
    declaration is the reader failing (exit 2)."""
    try:
        return check.check(ctx)
    except ConfigError:
        raise
    except Exception as err:  # noqa: BLE001 — an answer, not a swallow
        return Answer.unverifiable(
            f'{type(err).__name__} while checking: {err}')


# --- the registry and the list ------------------------------------------------
# An injection seam: anything here wins, so a test can add a check without
# editing the shipped list.
REGISTRY: dict[str, Check] = {}


def registry_for(operation: str) -> dict[str, Check]:
    """The checks shipped for `operation`, by name; the import is local
    because `steps` imports from here."""
    from agentic_sdlc.repo.conveyor import steps as step_defs
    known = step_defs.registry_for(operation)
    known.update(REGISTRY)
    return known


def _skippable(operation: str, names: Sequence[str],
               registry: Mapping[str, Check]) -> tuple[str, ...]:
    """The checks `[<operation>] skippable` declares; the import is local
    because `steps` imports from here."""
    from agentic_sdlc.repo.conveyor import steps as step_defs
    return step_defs.skippable_for(operation, tuple(names), dict(registry))


def step_names(operation: str) -> tuple[str, ...]:
    """The ordered check list from `[<operation>] steps`; a misspelled name
    is exit 2, never a quietly shorter belt."""
    from agentic_sdlc.repo.conveyor import steps as step_defs
    known = registry_for(operation)
    names = step_defs.steps_for(operation, known)
    step_defs.validate_config(operation, names, known)
    return names


def plan_defect(registry: Mapping[str, Check], names: Sequence[str]) -> str:
    """'' when this list can be run whole, else why it cannot."""
    if not names:
        return ('no checks to run — the list is empty, and a run that asked '
                'nothing must not report ok')
    missing = [n for n in names if n not in registry]
    if missing:
        return ('no check is registered for '
                + ', '.join(repr(m) for m in missing))
    return ''


def done_state(cfg: 'vocabulary.PmConfig', kind: str) -> str:
    """The first state of `[pm.states.<kind>] done` — what a belt writes,
    never a literal; `vocabulary.flow_of` refuses an undeclared flow at exit 2."""
    return vocabulary.flow_of(cfg, kind).by_category[vocabulary.DONE_CATEGORY][0]


# --- the middle tap: one check resolved ---------------------------------------
# `rung.enter` is `pm ready-for`'s, `rung.leave` is the arrival's; this is the
# one between, and what each field DERIVES from is the rendered schema's note.
#
# **There is deliberately no `rung.exit_failed`.** A belt that writes nothing
# emits these rows with false verdicts and no `rung.leave`: the ABSENCE is the
# signal, and a kind saying "it did not happen" is the tool narrating.
def verdict_row(rung: str, grain: str, check: str, answer: Answer,
                ran: str, ts: str = '') -> dict:
    """One resolved check, as the belt printed it: `detail` is the same
    sentence the line carries, so the row and the line cannot disagree."""
    return dict(zip(ledger.VERDICT_KEYS, (
        ts or ledger.utc_now(), ledger.KIND_VERDICT, rung, grain, check,
        VERDICT_WORDS[answer.truth], answer.detail, ran)))


class Verdicts:
    """The tap one run emits through: the config the seam needs, the grain the
    rows are routed by, and what each check runs. A check the caller answered
    with `--skip` mints NOTHING here — its judgement is a field on the
    arrival's disposition row (D6), and a verdict for a check nobody asked is
    the false verdict rule 4 calls a sin."""

    def __init__(self, cfg, operation: str, grain: str, ran: Mapping[str, str]):
        self.cfg = cfg
        self.operation = operation
        self.grain = grain
        self.ran = ran

    def say(self, check: str, answer: Answer) -> None:
        """Emit one row and contribute NO line — "never load-bearing" (D1)
        made structural. An unreachable sink is `emit.emit`'s own finding on
        stderr; a malformed `[emit]` was refused before the first check."""
        emit.emit(self.cfg, emit.TAP_VERDICT,
                  verdict_row(self.operation, self.grain, check, answer,
                              self.ran.get(check, '')))


def ran_for(operation: str, names: Sequence[str],
            registry: Mapping[str, Check]) -> dict[str, str]:
    """{check: what it runs} — what `install-sdlc` renders in that column."""
    from agentic_sdlc.repo.conveyor import steps as step_defs
    commands = step_defs.commands_for(operation, tuple(names), dict(registry))
    return {name: step_defs.ran_of(name, commands) for name in names}


# --- the run ------------------------------------------------------------------
Writer = Callable[[Context, str, Sequence[tuple[str, str]]], tuple[bool, str]]
Recorder = Callable[[Sequence[tuple[str, str]]], str]


def run(registry: Mapping[str, Check], names: Sequence[str], ctx: Context,
        *, force: bool = False, skips: Mapping[str, str] | None = None,
        state: str = '', write: Writer | None = None,
        record: Recorder | None = None,
        surfacer: 'lessons.Surfacer | None' = None,
        verdicts: 'Verdicts | None' = None,
        shared: Shared | None = None) -> Result:
    """Ask every check the caller did not answer, print each, then write once
    or not at all.

    `state` and `write` are handed in so decision and mechanism are two
    functions with one seam; `record` mints a forced write's `deviation` row
    and returns '' or why it could not; `state == ''` writes nothing.
    `surfacer` contributes lines beside the verdicts and CANNOT change one;
    `verdicts` emits one `check.verdict` event per check ASKED, and decides
    nothing either — a run given neither behaves exactly as it did. `shared`
    hands a check a many-id close already asked the answer it got.

    `skips` is check -> why, already graded against `[<op>] skippable` by the
    caller: a check in it is NOT asked, because the point is that the
    expensive question goes unasked once someone answered it. What was
    answered is COLLECTED and handed to `write`, the arrival that records it.
    """
    op = ctx.operation
    defect = plan_defect(registry, names)
    if defect:
        return Result((f'[{op}] error — {defect}',), (), '', 2, defect)
    answered = dict(skips or {})
    lines: list[str] = []
    false: list[tuple[str, str]] = []
    dispositioned: list[tuple[str, str]] = []
    if surfacer is not None:
        # The MOVE surface: this run is about to touch its subject grain.
        lines += surfacer.at_entry()
    for name in names:
        if name in answered:
            # A FIRST-CLASS answer, not a hole in the list: the check is named
            # on its own line with the judgement that stood in for it.
            why = answered[name]
            lines.append(f'[{op}] {verdict.SKIPPED}: {name} — "{why}"')
            dispositioned.append((name, why))
            if surfacer is not None:
                lines += surfacer.at_check(name)
            continue
        try:
            if shared is not None and name in shared.names:
                answer = shared.answer(
                    name, functools.partial(ask, registry[name], ctx),
                    ctx.version)
            else:
                answer = ask(registry[name], ctx)
        except ConfigError as err:
            # D11: the reader failed at this check; nothing after it runs.
            refused = f'check {name!r}: {err}'
            lines.append(f'[{op}] error — {refused}; no status written')
            return Result(tuple(lines), tuple(n for n, _ in false), '', 2,
                          refused)
        if answer.is_true:
            lines.append(f'[{op}] {VERDICT_WORDS[answer.truth]}: {name}'
                         + (f' — {answer.detail}' if answer.detail else ''))
        else:
            # A check that is not true and gave no reason has a defect, and the
            # defect is what gets reported — and carried, so the emitted row
            # says what the line said rather than nothing.
            answer = replace(answer, detail=answer.detail or NO_REASON)
            lines.append(f'[{op}] {VERDICT_WORDS[answer.truth]}: {name}: '
                         f'{answer.detail}')
            false.append((name, answer.detail))
        if verdicts is not None:
            verdicts.say(name, answer)
        if surfacer is not None:
            # The RULE surface, and the blockers this check named — after the
            # verdict line, because the verdict is the check's own business.
            lines += surfacer.at_check(name, answer.names)
    names_false = tuple(n for n, _ in false)
    names_skipped = tuple(n for n, _ in dispositioned)
    if false and not force:
        lines.append(f'[{op}] error — {len(false)} check(s) false; '
                     f'no status written')
        return Result(tuple(lines), names_false, '', 1,
                      skipped=names_skipped)
    if not state:
        # adopt: checks only. `--force` was refused before this point.
        # The census is what was ASKED and came out true; a skipped check
        # counted as true here would be rule 4's first sin with a number on it.
        census = f'{len(names) - len(dispositioned)} check(s) true'
        if dispositioned:
            census += f', {len(dispositioned)} skipped'
        lines.append(f'[{op}] ok — {census}; nothing to write')
        return Result(tuple(lines), names_false, '', 0,
                      skipped=names_skipped)
    if write is None:
        raise ValueError(f'{op} writes {state!r} and no writer was given')
    landed, said = write(ctx, state, tuple(dispositioned))
    if said:
        # As LINES: a belt that reflowed the fork destroyed the pasteable
        # commands the arrival exists to offer.
        head, *rest = said.splitlines()
        lines.append(f'[{op}] write: {head}')
        lines.extend(rest)
    if not landed:
        lines.append(f'[{op}] error — the write was refused; no status written')
        return Result(tuple(lines), names_false, '', 1,
                      skipped=names_skipped)
    if false:
        lines.append(f'[{op}] forced — {ctx.version} → {state} over '
                     f'{len(false)} false check(s)')
        blocked = record(false) if record is not None else ''
        if blocked:
            lines.append(f'[{op}] WARNING — the deviation row naming the '
                         f'forced checks was not written: {blocked}')
    else:
        lines.append(f'[{op}] ok — {ctx.version} → {state}')
    return Result(tuple(lines), names_false, state, 0, skipped=names_skipped)


# --- the verb -----------------------------------------------------------------

USAGE = """\
{synopsis}

{run}

  {subject}
              {subject_is}
{flags}
One line per check — `ok: <check> — <detail>`, `error: <check>: <what is
false>`, `unverifiable: <check>: <why>` (counts as false){skipped_line} —
then one of:

{verdicts}

{after}

A `lesson` row recorded against the subject's grain, or a check's name, is
printed beside that verdict with its `source` path and emitted on the
`[emit]` sink. It is a record, never a gate: it changes no verdict and no
exit code.

Exit codes: {exits}\
"""

# What each kind of subject IS, keyed by its segment count in SUBJECT: one
# segment is a version, anything else a grain id.
SUBJECT_IS = {
    1: 'a version — the release this belt is about: one literal path\n'
       '              segment, with no whitespace, glob, separator, scheme or\n'
       '              "." / ".." segment',
    2: 'a grain id — the same grammar `pm` uses, segment for segment',
}

# The parts of the help that differ between a belt that WRITES and one that
# is checks only, keyed by whether it writes. The renderer asks `WRITES`, never
# the operation's name, so the next checks-only belt is described correctly by
# being declared one.
HELP_PARTS = {
    True: {
        'run': 'Run every check in the {state} list, print each one, then '
               'write ONCE or not\nat all: {writes}',
        'skipped_line': ', or `skipped:\n<check> — "<why>"` (you answered it)',
        'verdicts': '    [{state}] ok — {subject} → <state>\n'
                    '    [{state}] error — N check(s) false; no status written\n'
                    '    [{state}] forced — {subject} → <state> over N false '
                    'check(s)',
        'after': 'and, after a write, `next:` lines saying what is yours to '
                 'do. Nothing else\nis written, moved, bumped, retitled, '
                 'pushed or tagged.',
        'exits': '0 written (or nothing to write), 1 a check is false and '
                 'nothing was\nwritten, 2 the input was refused or the '
                 'declaration could not be read.',
    },
    False: {
        'run': 'Run every check in the {state} list and print each one. It '
               'writes nothing —\nit is checks only: it sets no status and '
               'files no row of its own, so the\nverdict is the exit code and '
               'the lines above it. Where `[emit]` declares a\nsink, each '
               'verdict is emitted there, as on every belt.',
        'skipped_line': '',
        'verdicts': '    [{state}] ok — N check(s) true; nothing to write\n'
                    '    [{state}] error — N check(s) false; no status written',
        'after': 'and, when every check is true, `next:` lines saying what is '
                 'yours to do.\nNothing is moved, bumped, retitled, pushed or '
                 'tagged.',
        'exits': '0 every check true, 1 a check is false, 2 the input\nwas '
                 'refused or the declaration could not be read.',
    },
}


def render_usage(operation: str) -> str:
    """The belt's `--help`, off `WRITES` and `SUBJECT` alone."""
    parts = HELP_PARTS[bool(WRITES[operation])]
    subject = SUBJECT[operation][2]
    words = {'state': operation, 'subject': subject,
             'writes': _writes(operation)}
    return USAGE.format(
        synopsis=_synopsis(operation), subject=subject,
        subject_is=SUBJECT_IS[1 if SUBJECT[operation][0] == 1 else 2],
        flags=_flags(operation).format(state=operation),
        **{key: text.format(**words) for key, text in parts.items()})

CLOSE_USAGE = f"""\
agentic-sdlc {CLOSE_VERB} story   <story-id> [<story-id> …]  [{SKIP_FLAG} <check> "<why>"] [--force]
agentic-sdlc {CLOSE_VERB} feature <feature-id> [<feature-id> …]  [{SKIP_FLAG} <check> "<why>"] [--force]
agentic-sdlc {CLOSE_VERB} feature <feature-id> {RECORD_FLAG} <path>  [{SKIP_FLAG} <check> "<why>"] [--force]

The two INNER belts (SDLC.md §0). Each runs its checks, prints one line per
check, and then writes exactly one thing or nothing: the grain's status, set
to the first state of its kind's `done` category (`[pm.states.<kind>] done`).

  story    the story exists; `verify --story` (the `[verify] story` make
           target) is green; nothing outside the roadmap directory is
           uncommitted; the story carries a `done:` line. Name many
           stories in one call and the rung and `committed` run ONCE; each
           story gets its own verdict and its own write.
  feature  every story is in the `done` category (each one that is not is
           named, by `pm ready-for feature`); `reviewed:` points at a record
           that parses; no finding in it is `open`; `verify --feature` (the
           `[verify] feature` make target) is green. Name many features in
           one call and the rung runs ONCE; each feature gets its own
           verdict and its own write. `{RECORD_FLAG} <path>` closes on a
           record that just landed: the checks read <path>, and the one
           write stamps `reviewed:` with the status — a refused close
           stamps nothing.

A rung reuses a green run recorded on the same tree minus what a belt writes
(each `status:` line and the belt's ledger rows), so a close on the same
commit does not re-buy it; `[verify] reuse_ignores_status = false` keys every
rung on every byte, for a project whose rung target reads statuses.

Any check false → `error:` lines, exit 1, no status written. `--force` writes
anyway and the ledger row names the false checks. `{SKIP_FLAG} <check> "<why>"`
is the other answer: the caller answered that check, so it is not asked, the
close is clean, and a `disposition` row carries the reason — for any check the
project named in `[story] skippable` / `[feature] skippable`, which stock
leaves empty. `agentic-sdlc {CLOSE_VERB} story --help` prints the full line
shapes. The belt above these two is `agentic-sdlc release <version>`.\
"""


def _spoken(operation: str) -> str:
    """How this operation is INVOKED, which is not always its name."""
    return (f'{CLOSE_VERB} {operation}' if operation in CLOSE_OPERATIONS
            else operation)


def _writes(operation: str) -> str:
    kind = WRITES[operation]
    if not kind:
        return 'It writes nothing — it is checks only.'
    return (f'the {kind}\'s status, set to the first state of '
            f'[pm.states.{kind}] done. Any check false → exit 1 and no write.')


# The two flags a belt that WRITES takes, and what a checks-only belt says
# about them instead. Both are named either way: a flag refused here and
# working one belt over is what rule 11 says must not be discovered by trying.
WRITE_FLAGS = f"""\
  {SKIP_FLAG} <check> "<why>"
              you ANSWERED that check: it is not asked, the close is a clean
              one, and a `disposition` row keeps the reason against the grain.
              Only a check named in `[{{state}}] skippable` may be skipped
              (stock declares none), and a skip with no reason is refused —
              an unexplained skip is a deviation, and `--force` is its verb.
              Repeatable, once per check
  --force     write anyway; the milestone's ledger.jsonl gets one `deviation`
              row naming the checks that were false
"""

CHECKS_ONLY_FLAGS = f"""\
  {SKIP_FLAG} / --force
              neither is accepted here, and both are exit 2: this belt writes
              nothing, so there is no status to force and a skip would be a
              judgement with nowhere to be recorded. They are the close belts'
              flags — `close story`, `close feature`, `release`
"""


def _flags(operation: str) -> str:
    return WRITE_FLAGS if WRITES[operation] else CHECKS_ONLY_FLAGS


# What the many-id form of a close does, under its synopsis line (#95).
MANY_IDS = {
    OP_STORY: """\
              many stories, one call: the checks that read the tree —
              `[verify] story` and `committed` — run ONCE; `story-exists` and
              `evidence-written` run per story. Each story is printed with its
              lines and gets its own verdict and its own write; `--force` and
              `--skip` apply to every story named, one row each. A story
              already in a `done` state is reported and skipped. Exit 1 when
              any story was refused, 0 when every other one wrote""",
    OP_FEATURE: """\
              many features, one call: the check that reads the tree —
              `[verify] feature` — runs ONCE; `stories-done`,
              `review-recorded` and `findings-landed` run per feature. Each
              feature is printed with its lines and gets its own verdict and
              its own write; `--force` and `--skip` apply to every feature
              named, one row each. A feature already in a `done` state is
              reported and skipped. Exit 1 when any feature was refused, 0
              when every other one wrote""",
}


# What `--review-record` does, under its synopsis line.
RECORD_NOTE = """\
              the review record landed: review-recorded and findings-landed
              read <path>, and the one write stamps `reviewed: <path>` with
              the `done` status. A refused close stamps nothing. One feature
              id only; a repo-relative path"""


def take_record(rest: Sequence[str]) -> tuple[str, list[str], str]:
    """(the `--review-record` path or '', the other arguments, '' or the usage
    defect). Both `--review-record <path>` and `--review-record=<path>`."""
    record, kept, defect = '', [], ''
    args = list(rest)
    index = 0
    while index < len(args):
        arg = args[index]
        index += 1
        if arg == RECORD_FLAG or arg.startswith(f'{RECORD_FLAG}='):
            if arg == RECORD_FLAG:
                value = args[index] if index < len(args) else ''
                index += 1
            else:
                value = arg.split('=', 1)[1]
            if not value:
                defect = f'{RECORD_FLAG} needs a path'
            elif record:
                defect = f'{RECORD_FLAG} is given twice — one record, one stamp'
            record = record or value
        else:
            kept.append(arg)
    return record, kept, defect


def _synopsis(operation: str) -> str:
    """The invocation lines: a belt that writes carries its two flags, and one
    that writes nothing is one line, because it takes neither."""
    spoken, subject = _spoken(operation), SUBJECT[operation][2]
    head = f'agentic-sdlc {spoken} {subject}'
    if not WRITES[operation]:
        return head
    lines = [head, f'{head} {SKIP_FLAG} <check> "<why>"', f'{head} --force']
    if operation == OP_FEATURE:
        lines.append(f'{head} {RECORD_FLAG} <path>\n{RECORD_NOTE}')
    if operation in MANY_IDS:
        lines.append(f'{head} [{subject} …]\n{MANY_IDS[operation]}')
    return '\n'.join(lines)


def parse_flags(rest: Sequence[str]
                ) -> tuple[bool, dict[str, str], list[str], str]:
    """(--force, the checks `--skip` answered and why, positionals, '' or the
    usage defect).

    `--skip <check> "<why>"` takes its two words POSITIONALLY, so a reason
    opening with a dash is a reason and not a mistyped flag. WHICH checks may
    be skipped is `[<op>] skippable`, graded by `skip_defect` once the config
    is loaded. `--reason` and `--status` are named because a consumer's script
    may still carry them.
    """
    force = False
    skips: dict[str, str] = {}
    positional: list[str] = []
    args = list(rest)
    index = 0
    while index < len(args):
        arg = args[index]
        index += 1
        if arg == '--force':
            force = True
        elif arg == SKIP_FLAG:
            values = args[index:index + SKIP_ARITY]
            index += len(values)
            if len(values) < SKIP_ARITY:
                return False, {}, [], (
                    f'{SKIP_FLAG} takes a check and a reason — '
                    f'`{SKIP_FLAG} <check> "<why>"`. A skip with no reason is '
                    f'refused, because an unexplained skip IS a deviation and '
                    f'`--force` is already the verb for one')
            name, why = values
            defect = ledger.reason_defect(why)
            if defect:
                return False, {}, [], (
                    f'{SKIP_FLAG} {name}: {defect}. The reason is the whole '
                    f'difference between a judgement and a deviation, and the '
                    f'tree keeps it against the grain forever')
            if name in skips:
                return False, {}, [], (
                    f'{SKIP_FLAG} names {name!r} twice, with two reasons — '
                    f'one check, one answer')
            skips[name] = why
        elif arg in ('--reason', '--status'):
            return False, {}, [], (
                f'{arg} was removed in 0.2.0: a belt is its checks and then '
                f'one write. `--force` writes over false checks and the '
                f'ledger row names them; `pm ledger report` reads those rows')
        elif arg.startswith('-'):
            return False, {}, [], f'unknown option {arg!r}'
        else:
            positional.append(arg)
    return force, skips, positional, ''


def skip_defect(operation: str, asked: Mapping[str, str],
                declared: Sequence[str]) -> str:
    """'' when every `--skip` names a check this project DECLARED skippable,
    else why not — by name, which is the ship criterion.

    The tool has no opinion about which check is a judgement (rule 9); it has
    an opinion about whether the project said anything, and says so.
    """
    unknown = [name for name in asked if name not in declared]
    if not unknown:
        return ''
    listed = ', '.join(repr(name) for name in unknown)
    if declared:
        return (f'{listed} is not skippable — [{operation}] skippable declares '
                f'{", ".join(repr(name) for name in declared)}')
    return (f'{listed} is not skippable: this project declared no check '
            f'skippable, so nothing may be. Which checks are dispositionable '
            f'is yours to declare — `skippable = [{listed}]` under '
            f'[{operation}] in devkit.toml — or write anyway with --force, '
            f'which records a deviation naming every false check')


def _refuse(message: str) -> int:
    print(f'agentic-sdlc: {message}', file=sys.stderr)
    return 2


def _quote(value: str) -> str:
    shown = value if len(value) <= QUOTE_LIMIT else value[:QUOTE_LIMIT] + '…'
    return repr(shown)


def _plan_move(*flags: str) -> str:
    """The `pm add` that puts a milestone on the plan, through the vehicle."""
    return vehicle.command('pm', 'add', vocabulary.ROOT_ID,
                           inventory.MILESTONE_SLOT, *flags)


def version_defect(value: str) -> str:
    """'' when `value` may be joined onto the roadmap directory, else why
    not."""
    if not value:
        return 'the version is empty'
    if len(value) > MAX_VERSION:
        return (f'the version is too long ({len(value)} characters; the limit '
                f'is {MAX_VERSION})')
    if any(ch.isspace() for ch in value):
        return f'{_quote(value)} carries whitespace, which no milestone id has'
    if not inventory.segment_is_literal(value):
        return (f'{_quote(value)} is not a milestone id — globs, path '
                f'separators, schemes, absolute paths and the "." / ".." '
                f'segments are all refused')
    return ''


def subject_defect(operation: str, value: str) -> str:
    """'' when `value` COULD be this operation's subject, else why not — a fact
    about the INPUT and nothing more. It counted segments (the nested id shape,
    the path spelled as an id) and so refused every id a migrated tree holds;
    story-or-feature is a question about the GRAIN, which `_wrong_kind` asks."""
    segments, noun, _shape = SUBJECT.get(operation, SUBJECT['release'])
    if segments == 1:
        return version_defect(value)
    if any(ch.isspace() for ch in value):
        return f'{_quote(value)} carries whitespace, which no {noun} has'
    if len(value) > MAX_SUBJECT:
        return (f'the {noun} is too long ({len(value)} characters; the limit '
                f'is {MAX_SUBJECT})')
    defect = inventory.id_defect(value)
    return f'{_quote(value)} is not a {noun}: {defect}' if defect else ''


def _wrong_kind(cfg, operation: str, subject: str) -> str:
    """'' when the tree's grain for `subject` is this belt's kind, else why not.
    The half of the old segment count that was real — `close story` given a
    FEATURE id answers the wrong question about a real file — asked off
    `kind:`, so it holds for any id shape."""
    want = {OP_STORY: vocabulary.GRAIN_STORY,
            OP_FEATURE: vocabulary.GRAIN_FEATURE}.get(operation)
    if want is None:
        return ''
    found = inventory.kind_of(cfg, subject)
    if not found or found == want:
        return ''
    return (f'{_quote(subject)} is a {found}, not a {want} — '
            f'`close {found} {subject}` is the belt that asks about one')


def grain_path(cfg, operation: str, subject: str) -> Path | None:
    """The file a close operation's subject names, or None, through
    `inventory`'s own resolvers."""
    if operation == OP_STORY:
        return inventory.story_file(cfg, subject)
    return inventory.feature_file(cfg, subject)


def _config(root: Path | None) -> 'vocabulary.PmConfig':
    """The pm config, optionally re-rooted at a scratch tree."""
    cfg = vocabulary.load()
    return cfg if root is None else replace(cfg, root=Path(root))


def _writer(cfg: 'vocabulary.PmConfig', kind: str,
            record: str = '') -> Writer:
    """The one write, `pm <kind> <state> <id>` in process, so the CLI mints
    the `status` row and `check pm` reads what it wrote. The answered checks
    ride along: the write IS the arrival that records them, so a close that
    never happened leaves no row claiming a judgement (0.5.0/D6). The
    arrival's report comes back as LINES: squashing it joined the fork's two
    pasteable commands into one 555-character sentence. A `record` rides
    the same write as `--review-record`, so `reviewed:` is stamped only when
    the status lands.
    """
    from agentic_sdlc.repo.conveyor import steps as step_defs
    from agentic_sdlc.repo.pm import cli as pm_cli

    def write(ctx: Context, state: str,
              skipped: Sequence[tuple[str, str]] = ()) -> tuple[bool, str]:
        argv = [kind, state, step_defs.subject_grain(ctx)]
        if record:
            argv += [RECORD_FLAG, record]
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer), \
                contextlib.redirect_stderr(buffer):
            code = pm_cli.main(argv, skipped=tuple(skipped))
        said = buffer.getvalue().strip()
        return code == 0, f'`pm {" ".join(argv)}` exited {code}: {said}'

    return write


def _recorder(mledger: Path, operation: str, subject: str) -> Recorder:
    """The `deviation` row a forced write leaves, with `ledger.deviation_row`'s
    keys: `step` names every false check, `reason` carries each sentence."""
    def record(false: Sequence[tuple[str, str]]) -> str:
        reason = '; '.join(f'{name}: {why}' for name, why in false)
        # One row is one line; U+2028/9 are left to `ledger.dumps`.
        for char in ('\n', '\r', '\x00'):
            reason = reason.replace(char, ' ')
        if len(reason) > ledger.REASON_MAX:
            reason = reason[:ledger.REASON_MAX - 1] + '…'
        defect = ledger.reason_defect(reason)
        if defect:
            return defect
        row = {ledger.TS_FIELD: ledger.utc_now(),
               ledger.KIND_FIELD: ledger.KIND_DEVIATION,
               ledger.GRAIN_FIELD: subject, 'operation': operation,
               'step': ', '.join(name for name, _ in false),
               'outcome': FORCED, 'reason': reason}
        try:
            ledger.append_to(mledger, row)
        except (ledger.LedgerError, OSError) as err:
            return str(err)
        return ''

    return record


def _no_ledger(nowhere: str) -> Recorder:
    """The recorder for a run whose milestone is not in the tree: it records
    nothing and says why, so a forced write can never print as though a row
    landed. Only a checks-only belt gets here, but `run` may not assume that
    and a silent recorder is rule 4's second sin in miniature.
    """
    def record(false: Sequence[tuple[str, str]]) -> str:
        return f'{nowhere} to hold a ledger row'

    return record


def _milestone_id(cfg, operation: str, subject: str) -> str:
    """The milestone this operation's subject belongs to — followed through the
    grain's BINDINGS for a close, and the subject itself for release/adopt.
    Splitting the id on `/` read the nested shape."""
    if operation in ('release', 'adopt'):
        # A VERSION; the milestone is whichever one CLAIMS it. `release` takes
        # the version a human says out loud, and the plan lists ids.
        return inventory.milestone_of_version(cfg, subject) or subject
    return inventory.milestone_of(cfg, subject) or subject


def _subject_grain(ctx: Context) -> str:
    """The grain this run is ABOUT, asked of the check lists so the lesson
    surface and the write cannot disagree about what is being touched."""
    from agentic_sdlc.repo.conveyor import steps as step_defs
    try:
        return step_defs.subject_grain(ctx)
    except Exception:  # noqa: BLE001 — a grain nobody could name is no grain
        return ctx.version


def _after(cfg: 'vocabulary.PmConfig', operation: str, subject: str) -> list[str]:
    """The `next:` lines from `steps.AFTER` with the tree's words filled in;
    a missing `branch:` renders as the placeholder."""
    from agentic_sdlc.repo.conveyor import steps as step_defs

    mid = _milestone_id(cfg, operation, subject)
    milestone = inventory.grain(cfg, mid, vocabulary.GRAIN_MILESTONE)
    branch = (milestone.field('branch') if milestone is not None else '') \
        or '<branch>'
    try:
        mainline = vocabulary.mainline_branch()
        commands = step_defs.commands_for(operation)
    except ConfigError:
        mainline, commands = '<mainline>', {}
    return [f'next: {line}' for line in step_defs.after_lines(
        operation, commands, version=subject, branch=branch,
        mainline=mainline)]


def main(argv: Sequence[str], *, root: Path | None = None,
         registry: Mapping[str, Check] | None = None,
         steps: Sequence[str] | None = None,
         write: Writer | None = None) -> int:
    """`argv[0]` is the verb (`release` / `adopt` / `close`); the keyword
    arguments are injection seams for tests."""
    # One read scope for the belt (#100): its checks share one walk per pool,
    # and its one write, through `core.apply`, drops the snapshot.
    with inventory.reading_tree():
        return _main(argv, root=root, registry=registry, steps=steps,
                     write=write)


def _main(argv: Sequence[str], *, root: Path | None, registry:
          Mapping[str, Check] | None, steps: Sequence[str] | None,
          write: Writer | None) -> int:
    args = list(argv)
    if not args:
        return _refuse(
            f'an operation is required (expected: {", ".join(OPERATIONS)})')
    operation, rest = args[0], args[1:]
    if operation in ('-h', '--help', 'help'):
        print(__doc__.strip())
        return 0
    if operation == CLOSE_VERB:
        if rest and rest[0] in ('-h', '--help', 'help'):
            print(CLOSE_USAGE)
            return 0
        if not rest:
            return _refuse(
                f'{CLOSE_VERB} needs a grain '
                f'(expected: {", ".join(CLOSE_OPERATIONS)})')
        if rest[0] not in CLOSE_OPERATIONS:
            return _refuse(
                f'unknown grain {rest[0]!r} — `{CLOSE_VERB}` closes one of '
                f'{", ".join(CLOSE_OPERATIONS)}. A milestone closes through '
                f'`{vehicle.command("release", vehicle.Slot("<version>"))}`, '
                f'which is the belt above these two')
        operation, rest = rest[0], rest[1:]
    if operation not in OPERATIONS:
        return _refuse(f'unknown operation {operation!r} '
                       f'(expected: {", ".join(OPERATIONS)})')
    spoken = _spoken(operation)
    if any(a in ('-h', '--help', 'help') for a in rest):
        print(render_usage(operation))
        return 0

    record, rest, record_defect = take_record(rest)
    if record_defect:
        return _refuse(f'{spoken}: {record_defect}')
    if record and operation != OP_FEATURE:
        return _refuse(f'{spoken}: {RECORD_FLAG} is `{CLOSE_VERB} '
                       f'{OP_FEATURE}`\'s flag — only a feature carries a '
                       f'review record')
    force, skips, positional, flag_defect = parse_flags(rest)
    segments, noun, shape = SUBJECT[operation]
    if flag_defect:
        return _refuse(f'{spoken}: {flag_defect}')
    if record and len(positional) != 1:
        return _refuse(f'{spoken}: {RECORD_FLAG} stamps ONE feature; got '
                       f'{len(positional)} id(s) — close the others by name')
    if not positional and operation != 'release':
        example = '0.2.0' if segments == 1 else vehicle.Slot(shape)
        return _refuse(f'{spoken} needs a {shape} — the {noun} to close, e.g. '
                       f'`{vehicle.command(*spoken.split(), example)}`')
    # A close takes many ids (#95): one invocation, one run of the checks
    # that read the tree, and one verdict and write per grain.
    if len(positional) > 1 and operation not in CLOSE_OPERATIONS:
        return _refuse(f'{spoken} takes exactly one {shape}; got '
                       f'{len(positional)} — one operation, one grain')
    twice = sorted({one for one in positional if positional.count(one) > 1})
    if twice:
        return _refuse(f'{spoken} names {", ".join(map(_quote, twice))} more '
                       f'than once — one {WRITES[operation]}, one verdict')
    # `release` alone resolves its subject from the plan, below, once the
    # config is loaded; every other operation is named on the command line.
    subject = positional[0] if positional else ''
    # A value that WAS given is graded, empty or not. Reading `release ''` as
    # "no argument" would resolve it from the plan and run the belt over a
    # version nobody named — the refusal matrix exists to stop exactly that.
    for given in positional:
        defect = subject_defect(operation, given)
        if defect:
            return _refuse(f'{spoken}: {defect}')
    kind = WRITES[operation]
    if force and not kind:
        return _refuse(f'{spoken} writes nothing, so there is nothing to '
                       f'force — it is checks only')
    if skips and not kind:
        # A `skipped:` line with no `disposition` behind it would be the
        # record this flag exists to make, missing.
        return _refuse(f'{spoken} writes nothing — not a status and not a row '
                       f'— so a skip has nowhere to be recorded; it is checks '
                       f'only. `{SKIP_FLAG}` is a close belt\'s flag: '
                       f'{CLOSE_VERB} story, {CLOSE_VERB} feature, release')

    # Everything above refused without touching the filesystem.
    try:
        cfg = _config(root)
        names = tuple(steps) if steps is not None else step_names(operation)
        known = (dict(registry) if registry is not None
                 else registry_for(operation))
        # Read before the first check, so an undeclared `done` category fails
        # before anything runs.
        state = done_state(cfg, kind) if kind else ''
        # The DECLARATION `--skip` is graded against; a malformed one is exit 2
        # here rather than a skip refused for a reason nobody can see.
        declared = _skippable(operation, names, known) if skips else ()
        # The `ran` column, resolved once, beside the two reads above: a
        # malformed `[<op>.commands]` is exit 2 before the first check, not a
        # field this run then has to leave out of its events.
        ran = ran_for(operation, names, known)
        # The sink's own declaration too (rule 9): the SINK is never
        # load-bearing, the DECLARATION is like every other one.
        if emit.declared():
            emit.settings()
    except ConfigError as err:
        return _refuse(f'{spoken}: {err}')
    defect = plan_defect(known, names)
    if defect:
        return _refuse(f'{spoken}: {defect}')
    defect = skip_defect(operation, skips, declared)
    if defect:
        return _refuse(f'{spoken}: {defect}')
    # The KIND needs the TREE, so it sits below the config load; the guard
    # above it stays a fact about the input.
    for given in positional:
        wrong = _wrong_kind(cfg, operation, given)
        if wrong:
            return _refuse(f'{spoken}: {wrong}')

    if operation == 'release':
        # The plan already knows which version is current, so the human does
        # not retype it — and shipping OUT of order is what a belt should stop.
        current = inventory.current_release(cfg)
        if not subject:
            if current is None:
                return _refuse(
                    f'{spoken} needs a version, and the plan cannot supply one: '
                    f'{cfg.rel(inventory.releases_file(cfg))} declares no `order` '
                    f'(or every entry in it has shipped). Name the version, or '
                    f'schedule the milestone that carries it: '
                    f'`{_plan_move()}`')
            subject = current
            defect = subject_defect(operation, subject)
            if defect:
                return _refuse(
                    f'{spoken}: the plan names {subject!r} as the current '
                    f'release, and {defect}')
            print(f'[{operation}] the plan names {subject} as the current '
                  f'release — '
                  f'{cfg.rel(inventory.releases_file(cfg))}, [pm] version_at = '
                  f'{cfg.version_at!r}')
        elif current is not None and subject != current:
            return _refuse(
                f'{spoken} {subject}: the current release is {current!r} — '
                f'shipping out of the order declared in '
                f'{cfg.rel(inventory.releases_file(cfg))} is refused, and nothing '
                f'was written. Re-sequence the plan with '
                f'`{_plan_move("--before", vehicle.Slot("<id>"))}` '
                f'if {subject} really goes first')

    belt = Belt(cfg=cfg, operation=operation, kind=kind, known=known,
                names=names, state=state, force=force, skips=skips, ran=ran,
                write=write, record=record)
    if operation in CLOSE_OPERATIONS:
        return _close_grains(belt, positional)
    return _close(belt, subject)


@dataclass(frozen=True)
class Belt:
    """One invocation's reading, made once: everything a belt run needs
    except the subject it is about."""

    cfg: 'vocabulary.PmConfig'
    operation: str
    kind: str
    known: Mapping[str, Check]
    names: tuple[str, ...]
    state: str
    force: bool
    skips: Mapping[str, str]
    ran: Mapping[str, str]
    write: Writer | None
    record: str = ''


def _close_grains(belt: Belt, subjects: Sequence[str]) -> int:
    """`close story|feature <id> [<id> …]`: each id its own verdict and its
    own write, printed with its lines; the checks `steps.asked_once` names
    asked once for all of them (#95). A grain already in a `done` state is
    reported and skipped. Exit 1 when any id was refused, 0 when every other
    one wrote."""
    from agentic_sdlc.repo.conveyor import steps as step_defs

    many = len(subjects) > 1
    try:
        once = step_defs.asked_once(belt.operation, belt.names)
    except ConfigError as err:
        return _refuse(f'{_spoken(belt.operation)}: {err}')
    shared = Shared(once)
    done = vocabulary.flow_of(belt.cfg, belt.kind).by_category[
        vocabulary.DONE_CATEGORY]
    written, already, refused = [], [], []
    for index, subject in enumerate(subjects, 1):
        if many:
            print(f'[{belt.operation}] {index} of {len(subjects)}: {subject}')
        status = _status_of(belt.cfg, belt.kind, subject)
        if status in done:
            print(f'[{belt.operation}] {subject} is already {status}, a done '
                  f'state — skipped: no check asked, nothing written')
            already.append(subject)
            continue
        code = _close(belt, subject, shared=shared, after=not many)
        if code == 2:
            return code
        (refused if code else written).append(subject)
    if many:
        tally = f'{len(written)} of {len(subjects)} written'
        if already:
            tally += f', {len(already)} already done'
        if refused:
            tally += f'; refused: {", ".join(refused)}'
        print(f'[{belt.operation}] {tally}')
        if written:
            for line in _after(belt.cfg, belt.operation, written[-1]):
                print(line)
    return 1 if refused else 0


def _status_of(cfg: 'vocabulary.PmConfig', kind: str, subject: str) -> str:
    """The grain's `status:`, or '' when it cannot be read — the checks then
    say why, which is their business and not this skip's."""
    try:
        found = inventory.grain(cfg, subject, kind)
    except Exception:  # noqa: BLE001 - an unreadable grain is not a done one
        return ''
    return ((found.field(vocabulary.FIELD_STATUS) or '')
            if found is not None else '')


def _close(belt: Belt, subject: str, *, shared: Shared | None = None,
           after: bool = True) -> int:
    """One belt run over one subject: the checks, then one write or none."""
    cfg, operation, kind = belt.cfg, belt.operation, belt.kind
    spoken = _spoken(operation)
    mid = _milestone_id(cfg, operation, subject)
    # The GRAIN, not a directory: what a belt needs is the milestone's document
    # (whose status it writes) and the ledger its rows land in, and both are
    # addressed by id now.
    mfile = inventory.milestone_file(cfg, mid)
    mledger = ledger.ledger_for(cfg, mid) if mfile is not None else None
    nowhere = f'no milestone {mid!r} in {cfg.rel(cfg.roadmap)}/'
    # A belt that WRITES needs the grain, and is refused BEFORE the first
    # check. The sentence names what was looked for: "no milestone
    # 'st-nobody-wrote-this'" about a STORY id sent the reader hunting.
    if mfile is None and kind:
        missing = (nowhere if operation in ('release', 'adopt')
                   else f'no {operation} {subject!r} in '
                        f'{cfg.rel(cfg.roadmap)}/, or it is bound to no '
                        f'milestone')
        print(f'agentic-sdlc: {spoken} {subject}: {missing} — refused, and '
              f'nothing was written', file=sys.stderr)
        return 1
    if not kind:
        # Checks only (D12): a milestone carrying the version is neither an
        # entry condition nor a place this run could write to. WHERE the
        # project tracks the bump is the project's business, the same way
        # `[pm.states.*]` is. One sentence either way — "a row would land in
        # <ledger>" read as a write this belt might make (#25).
        print(f'[{operation}] {NOTHING_RECORDED}, with or without a '
              f'milestone carrying {subject}; {ANYWHERE}')

    ctx = Context(root=cfg.root, operation=operation, version=subject,
                  record=belt.record)
    # ONE grain for both taps: the row a lesson surfaces against and the row a
    # verdict is filed under are the same grain or they are two logs.
    grain = _subject_grain(ctx)
    write = (belt.write if belt.write is not None
             else _writer(cfg, kind, belt.record))
    result = run(belt.known, belt.names, ctx, force=belt.force,
                 skips=belt.skips, state=belt.state, write=write,
                 record=(_recorder(mledger, operation, subject)
                         if mledger is not None else _no_ledger(nowhere)),
                 surfacer=lessons.surfacer_for(cfg, operation, grain),
                 verdicts=Verdicts(cfg, operation, grain, belt.ran),
                 shared=shared)
    for line in result.lines:
        print(line)
    if result.refused:
        # D11: one line on stderr, exit 2.
        return _refuse(f'{spoken}: {result.refused}')
    if result.exit_code == 0 and after:
        for line in _after(cfg, operation, subject):
            print(line)
    return result.exit_code
