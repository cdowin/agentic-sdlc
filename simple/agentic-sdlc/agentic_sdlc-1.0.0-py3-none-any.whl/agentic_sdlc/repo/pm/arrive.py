"""arrive.py — ARRIVAL is the one event: a grain reaches a state (0.5.0/D3).

Everything a move says and writes reads that one event, all of it DERIVED from
what the project declared:

    1  the status is written            `pm/cli.py`, unchanged
    2  the fork is asked                `[pm.arrive.<kind>.<state>]` ask/answers
    3  the disposition is recorded      one row, `none` when nobody answered
    4  the capability is named          `[pm.arrive.…] have`, as a CENSUS
    +  the tree's open work is reported the pressure line, silent when empty

Direction is not modelled and there is no transition table (0.5.0/D3); the row
grammar is in `pm/ledger.py` with every other row this package mints. Nothing
here decides, advises or refuses a move: `next:` is the belt's check list,
`have:` is inventory, `open:` is a census. *"You should close something"* is
an opinion and does not ship.
"""
from __future__ import annotations

import os
import re
import shlex
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from agentic_sdlc.core import apply, spawn
from agentic_sdlc.repo import emit, vehicle
from agentic_sdlc.repo.pm import inventory, ledger, remote, vocabulary

# The BELT names. Their home is `conveyor/driver.py` and `pm/` may not import
# `conveyor/`, so they are spelled once here rather than at each use; the
# release belt's subject is a version, and `_subject_of` asks `SUBJECT`.
STORY_BELT = 'story'
FEATURE_BELT = 'feature'
RELEASE_BELT = 'release'

# Which belt closes a grain of each kind, and which belt the grain ABOVE it
# needs next — `steps.registry_for` keys, and the whole of the mapping: the
# CHECKS each belt asks are read from the registry at runtime.
CLOSES = {vocabulary.GRAIN_STORY: STORY_BELT, vocabulary.GRAIN_FEATURE: FEATURE_BELT,
          vocabulary.GRAIN_MILESTONE: RELEASE_BELT}
# A milestone's `done` names nothing above it: inventing a sentence for what
# somebody does after a release would be this engine having an opinion.
ABOVE = {vocabulary.GRAIN_STORY: FEATURE_BELT, vocabulary.GRAIN_FEATURE: RELEASE_BELT}

# The frontmatter pointer a close stamps. A grain whose document does not
# carry the key is not counted for want of a field it never had.
RECORD_FIELD = 'reviewed'

PREFIX = '[pm]'

# The only `<…>` a rendered command leaves bare (`vehicle.Slot`): a name, so a
# `<x; touch p #>` typed where a value goes is quoted and never run.
PLACEHOLDER = re.compile(r'<[\w .-]+>')


def _say(line: str) -> None:
    """One line of the event's report, on STDERR — STDOUT stays the one line
    the write wrote, which is what a consumer parses (rule 6)."""
    print(f'{PREFIX} {line}' if line else PREFIX, file=sys.stderr)


# --- 2: the fork --------------------------------------------------------------
@dataclass(frozen=True)
class Said:
    """What the caller answered at an arrival, or nothing: the declared flag
    (`--by`) and the rest of the line as it was TYPED. The tool records a
    CLAIM and never verifies it (rule 9)."""

    answer: str = ledger.NO_DISPOSITION
    value: str = ''

    def __bool__(self) -> bool:
        return self.answer != ledger.NO_DISPOSITION


NOTHING = Said()


class Incomplete(Exception):
    """A declared answer typed without the rest of itself. Exit 2, by name."""


def take(node: vocabulary.Arrival | None,
         args: list[str]) -> tuple[Said, list[str]]:
    """Split a declared answer off the tail of `args`; `(NOTHING, args)` when
    the caller typed none. The flags come from the node's own `answers`, so a
    project declaring a different fork gets its own with no edit here."""
    if node is None:
        return NOTHING, list(args)
    flags = node.flags
    for index, arg in enumerate(args):
        if arg not in flags:
            continue
        value = ' '.join(args[index + 1:]).strip()
        if not value and node.carries_value(arg):
            raise Incomplete(
                f'{arg} needs the rest of the answer — this project declares '
                f'{", ".join(repr(a) for a in node.answers)}')
        # The one free-text field on the row, held to the guard every other
        # free-text field crosses: one row is one line.
        defect = ledger.reason_defect(value) if value else ''
        if defect:
            raise Incomplete(f'{arg} cannot record that answer: {defect}')
        return Said(arg, value), list(args[:index])
    return NOTHING, list(args)


AGENT_WORD = 'agent'


def agent_named(node: vocabulary.Arrival | None, said: Said) -> str | None:
    """The type typed where the project declared `agent <placeholder>`, or
    None — so `--review agent <type>` reads like `--by agent <type>`."""
    if node is None or not said:
        return None
    typed = said.value.split()
    for answer in node.answers:
        words = answer.split()
        if words[0] != said.answer:
            continue
        for at, word in enumerate(words[1:-1]):
            if (word == AGENT_WORD and PLACEHOLDER.fullmatch(words[at + 2])
                    and typed[at:at + 1] == [AGENT_WORD]):
                return typed[at + 1] if len(typed) > at + 1 else ''
    return None


def unknown_flag_hint(node: vocabulary.Arrival | None) -> str:
    """What a state DOES accept, for the refusal a flag it does not gets —
    rule 11: naming the answers beats naming the typo."""
    if node is None or not node.answers:
        return ''
    return (f' — arriving at {node.kind} {node.state} accepts '
            + ', '.join(repr(a) for a in node.answers))


def fork_lines(cfg: vocabulary.PmConfig, node: vocabulary.Arrival | None, gid: str,
               said: Said = NOTHING) -> list[str]:
    """The question and both answers, each a command that can be pasted. The
    command is the ARRIVAL itself: a move is idempotent, so re-running it with
    the answer records the disposition and writes nothing else — the cheap
    answer costs one paste and so does the expensive one. A move that already
    carries its answer prints no question at all.
    """
    if node is None or not node.ask or not cfg.pressure or said:
        return []
    lines = ['', node.ask]
    for index, answer in enumerate(node.answers):
        move = vehicle.command('pm', node.kind, node.state, gid,
                               *answer_argv(answer))
        lines.append(f'  {chr(ord("a") + index)}) {move}')
    return lines


def answer_argv(answer: str) -> list[str]:
    """A declared answer (`--why "<reason>"`) as argv: a word the project
    QUOTED is free text and stays quoted, a bare `<x>` of name characters stays
    a placeholder, and any other `<…>` is a value and is quoted like one."""
    try:
        words = shlex.split(answer, posix=False)
    except ValueError:
        return answer.split()
    out: list[str] = []
    for word in words:
        if word[:1] in ('"', "'"):
            out.extend(shlex.split(word))
        elif PLACEHOLDER.fullmatch(word):
            out.append(vehicle.Slot(word))
        else:
            out.append(word)
    return out


def disposition_of(row: dict) -> bool:
    """Is this row an arrival's disposition? ONE shape carries the word since
    0.5.0/D6, so this is the kind and nothing else — every reader asks it here
    rather than each branching on its own idea of the shape."""
    return row.get(ledger.KIND_FIELD) == ledger.KIND_DISPOSITION


# --- the ONE derivation, two renderers ----------------------------------------
@dataclass(frozen=True)
class Next:
    """What the conveyor asks next, derived once and rendered twice: the prose
    breadcrumb (`pm/cli.py`) and the `rung.leave` row both read THIS."""

    belt: str
    verb: str
    subject: str
    checks: tuple[str, ...]

    @property
    def action(self) -> str:
        """The command a caller can copy, with the belt's own argument shape —
        `subject` is `driver.SUBJECT`'s placeholder, never a value."""
        return vehicle.command(*self.verb.split(), vehicle.Slot(self.subject))


def derive_next(cfg: vocabulary.PmConfig, kind: str, to: str) -> Next | None:
    """The belt this arrival hands to, and the checks it will ask — or None.
    Three runtime sources: `[pm.states.<kind>]`, `driver.step_names(<belt>)`
    (the project's list, not the shipped one) and `driver.SUBJECT`."""
    category = vocabulary.flow_of(cfg, kind).category(to)
    belt = (CLOSES.get(kind) if category == vocabulary.IN_PROGRESS
            else ABOVE.get(kind) if category == vocabulary.DONE_CATEGORY else None)
    if belt is None:
        return None
    from agentic_sdlc.repo.conveyor import driver
    try:
        checks = tuple(driver.step_names(belt))
    except Exception:  # noqa: BLE001
        # A breadcrumb is a courtesy on top of a write that already
        # happened: a `[<belt>] steps` that belt would refuse is its finding
        # to report when it runs, not this line's after the status is on disk.
        return None
    if not checks:
        return None
    verb = belt if belt == RELEASE_BELT else f'{driver.CLOSE_VERB} {belt}'
    return Next(belt=belt, verb=verb,
                subject=driver.SUBJECT.get(belt, (0, '', ''))[2], checks=checks)


# --- 4: the capability census -------------------------------------------------
@dataclass(frozen=True)
class Capability:
    """One declared capability and whether the file is there."""

    path: str
    why: str
    installed: bool

    @property
    def line(self) -> str:
        """`have:` is INVENTORY, never *"you should run it"*; a declared file
        that is absent gets a NAMED line rather than silence (rule 11)."""
        state = ('is installed' if self.installed
                 else 'is DECLARED and not installed')
        return f'have: {self.path} {state} — {self.why}'


def capabilities(cfg: vocabulary.PmConfig,
                 node: vocabulary.Arrival | None) -> list[Capability]:
    """Which installed files this arrival's declaration binds to it. The
    mapping is a DECLARATION and never a list in this package."""
    if node is None:
        return []
    return [Capability(path=path, why=why,
                       installed=(cfg.root / path).is_file())
            for path, why in node.have]


# --- the pressure line --------------------------------------------------------
def _carry(count: int) -> str:
    return 'carries' if count == 1 else 'carry'


def _ledgers(count: int) -> str:
    return 'ledger' if count == 1 else 'ledgers'


@dataclass(frozen=True)
class Census:
    """The tree's open work, every number derived and none of them a
    threshold: a ceiling on how long a grain may stay in flight would be this
    package having an opinion about somebody's week (rule 9)."""

    open_count: int
    oldest_id: str
    oldest_seconds: int | None
    unanswered: int
    no_record: int
    record_pool: int
    wip: int
    unreadable: int
    unpushed_branch: str = ''

    def __bool__(self) -> bool:
        return self.open_count > 0

    @property
    def line(self) -> str:
        """One line, and only when there is something to say."""
        # The CATEGORY word, not a literal: renaming a state does not rename
        # the three categories the reader asked the tree with.
        head = f'open: {self.open_count} {vocabulary.IN_PROGRESS}'
        if self.wip and self.open_count > self.wip:
            head += f', over the declared [pm] wip of {self.wip}'
        if self.oldest_id:
            head += (f', oldest {self.oldest_id} '
                     f'{ledger.human_duration(self.oldest_seconds)}')
        clauses = []
        if self.unanswered:
            clauses.append(f'{self.unanswered} of {self.open_count} '
                           f'{_carry(self.unanswered)} no disposition')
        if self.no_record:
            clauses.append(f'{self.no_record} of {self.record_pool} '
                           f'{_carry(self.no_record)} no {RECORD_FIELD} record')
        if self.unreadable:
            clauses.append(f'{self.unreadable} '
                           f'{_ledgers(self.unreadable)} could not be read, so '
                           f'the ages above are short by whatever is in them')
        # Rule 11: a NAMED line. Silent when the work IS somewhere else.
        if self.unpushed_branch:
            clauses.append(f'{self.unpushed_branch} is on this disk only')
        return head + (' — ' + ', '.join(clauses) if clauses else '')


def _ledger_paths(cfg: vocabulary.PmConfig) -> list[Path]:
    """Every ledger a status row could be in — one per milestone plus the
    grainless one — read once each rather than once per grain."""
    paths = [ledger.grainless_path(cfg.roadmap)]
    for _mdir, mid in inventory.known_milestones(cfg):
        if mid:
            paths.append(ledger.ledger_for(cfg, mid))
    return list(dict.fromkeys(paths))


def _rows_by_grain(cfg: vocabulary.PmConfig) -> tuple[dict[str, list], int]:
    """`{grain id: its rows, oldest first}` and how many ledgers would not
    read. A damaged ledger is COUNTED and disclosed: an age computed over a
    file quietly dropped is rule 4's first sin."""
    out: dict[str, list] = {}
    unreadable = 0
    for path in _ledger_paths(cfg):
        try:
            rows = ledger.read_rows(path)
        except Exception:  # noqa: BLE001 — a count, never the exit code
            unreadable += 1
            continue
        for row in rows:
            gid = row.data.get(ledger.GRAIN_FIELD)
            if isinstance(gid, str) and gid:
                out.setdefault(gid, []).append(row)
    for rows in out.values():
        rows.sort(key=lambda r: str(r.data.get(ledger.TS_FIELD) or ''))
    return out, unreadable


def _answered(rows: list, state: str) -> bool:
    """Did the LAST disposition row for this grain answer the state it is in?
    Asked of the STATE, because a grain that bounced back has arrived again
    and the question is asked again (D3)."""
    for row in reversed(rows):
        if not disposition_of(row.data) or row.data.get('state') != state:
            continue
        return row.data.get('answer') not in (ledger.NO_DISPOSITION, None)
    return False


def answered_at(cfg: vocabulary.PmConfig, gid: str, state: str) -> bool:
    """Did this grain's LAST disposition for `state` carry an answer? Asked
    on a NO-OP, where a fresh `none` would SHADOW the answer already given."""
    path = ledger.ledger_of_grain(cfg, gid)
    try:
        rows = ledger.read_rows(path) if path is not None else []
    except Exception:  # noqa: BLE001 — unreadable is not answered
        return False
    return _answered(sorted((r for r in rows if r.data.get(ledger.GRAIN_FIELD) == gid),
                            key=lambda r: str(r.data.get(ledger.TS_FIELD) or '')), state)


def census(cfg: vocabulary.PmConfig, now: datetime | None = None) -> Census | None:
    """The whole tree's open work, or None when nothing is open — the WHOLE
    tree, because a grain nobody moves is otherwise silent forever."""
    if not cfg.pressure:
        return None
    grains = [g for g in inventory.grain_index(cfg).values()
              if g.kind in vocabulary.FLOW_KINDS
              and vocabulary.category_of(cfg, g.kind, g.status) == vocabulary.IN_PROGRESS]
    if not grains:
        return None
    rows, unreadable = _rows_by_grain(cfg)
    when = datetime.now(timezone.utc) if now is None else now
    oldest_id, oldest_seconds = '', None
    unanswered = no_record = record_pool = 0
    for grain in sorted(grains, key=lambda g: g.gid):
        status = [r for r in rows.get(grain.gid, ())
                  if r.data.get(ledger.KIND_FIELD) == ledger.KIND_STATUS]
        seconds = ledger.open_seconds(cfg, grain.kind, status, now=when)
        if seconds is not None and (oldest_seconds is None
                                    or seconds > oldest_seconds):
            oldest_id, oldest_seconds = grain.gid, seconds
        if not _answered(rows.get(grain.gid, ()), grain.status):
            unanswered += 1
        # The artifact a close requires is the pointer the grain's own
        # document carries; a grain with no such key is not counted.
        try:
            declared = grain.declares(RECORD_FIELD)
        except (OSError, UnicodeDecodeError):
            continue
        if declared:
            record_pool += 1
            if not grain.field(RECORD_FIELD) or not inventory.record_resolves(
                    cfg.root / grain.field(RECORD_FIELD)):
                no_record += 1
    elsewhere = remote.read(cfg.root)
    return Census(open_count=len(grains), oldest_id=oldest_id,
                  oldest_seconds=oldest_seconds, unanswered=unanswered,
                  no_record=no_record, record_pool=record_pool, wip=cfg.wip,
                  unreadable=unreadable,
                  unpushed_branch=(elsewhere.branch if elsewhere else ''))


# --- the crossing -------------------------------------------------------------
def crossing(cfg: vocabulary.PmConfig, kind: str, gid: str) -> str:
    """'' unless this write made the grain's PARENT ready, else the line
    saying so and naming the belt that closes it. Derivable on the write that
    caused it, so READY stops being a question somebody must remember to ask
    (0.3.0 made it prose in a document instead). READY is the parent's own
    `ready-for` verdict; the same-kind siblings only supply the count."""
    if not cfg.pressure:
        return ''
    grain = inventory.grain_index(cfg).get(gid)
    if grain is None or not grain.binding:
        return ''
    belt = ABOVE.get(kind)
    parent_kind = vocabulary.BINDS_TO.get(kind, ('', ''))[0]
    if belt is None or not parent_kind:
        return ''
    children = inventory.children(cfg, kind, grain.binding)
    if not children:
        return ''
    held = vocabulary.holds(cfg, kind, [(c.gid, c.status) for c in children],
                       vocabulary.DONE_CATEGORY)
    if not held:
        return ''
    # Imported here: `ready_for` imports `pm/cli.py`, which imports this.
    from agentic_sdlc.repo.pm import ready_for
    try:
        if ready_for.blockers(cfg, parent_kind, grain.binding):
            return ''
    except Exception:  # noqa: BLE001 — an edge that cannot answer is not READY
        return ''
    from agentic_sdlc.repo.conveyor import driver
    verb = belt if belt == RELEASE_BELT else f'{driver.CLOSE_VERB} {belt}'
    move = vehicle.command(*verb.split(), _subject_of(cfg, belt, grain.binding))
    return (f'ready: `{move}` — this write made '
            f'{grain.binding} READY (every {kind} is in {vocabulary.DONE_CATEGORY}: '
            f'{held.counted} of {held.counted})')


def _subject_of(cfg: vocabulary.PmConfig, belt: str, parent_id: str) -> str:
    """The argument that belt takes for this parent — its id, or the VERSION
    the parent declares when the belt's own `SUBJECT` says it takes one. Only
    the belt's own placeholder, standing in for a version nobody declared, is
    a `Slot`: a tree value is quoted whatever its shape (M1 of the 0.8.0
    vehicle review — a `version:` of `<x; touch p #>` ran out of `ready:`)."""
    from agentic_sdlc.repo.conveyor import driver
    noun = driver.SUBJECT.get(belt, (0, '', ''))
    if noun[1] != 'version':
        return parent_id
    return inventory.milestone_version(cfg, parent_id) or vehicle.Slot(noun[2])


# --- the emitted row ----------------------------------------------------------
def emit_leave(cfg: vocabulary.PmConfig, row: dict) -> None:
    """Write the leave event, or nothing, and never change the answer. A tree
    with no `[emit]` opted out. Every failure is a finding on stderr, never
    the exit code: a code that moved because a SINK was unwritable would make
    every move unusable from a hook."""
    try:
        if emit.declared():
            emit.emit(cfg, emit.TAP_LEAVE, row)
    except Exception as err:  # noqa: BLE001 — a finding, never the answer
        print(f'{emit.FINDING_PREFIX} WARNING — the {emit.TAP_LEAVE} event for '
              f'{row.get(ledger.GRAIN_FIELD)} was not recorded ({type(err).__name__}: '
              f'{err}); the write itself landed', file=sys.stderr)


# --- the whole event ----------------------------------------------------------
def remote_lines(cfg: vocabulary.PmConfig, kind: str, to: str) -> list[str]:
    """`remote:` — whether a milestone's branch exists anywhere but this disk.

    Asked at the arrival into `in_progress`, the moment the work starts being
    worth something. INVENTORY and a command, never a push (rule 9).
    """
    if kind != vocabulary.GRAIN_MILESTONE or vocabulary.category_of(cfg, kind,
                                                          to) != vocabulary.IN_PROGRESS:
        return []
    state = remote.read(cfg.root)
    if state is None or not state:
        return []
    where = ('has commits no remote-tracking ref holds' if state.published
             else 'is on no remote')
    return [f'remote: this branch {where} — the work is on this disk only',
            f'        `{remote.push_command(state.branch)}`']


def version_lines(cfg: vocabulary.PmConfig, kind: str, to: str) -> list[str]:
    """`next:` — the version edit a milestone's start owes R5 (#68, D2).

    Asked only under `[pm] version_at = "start"`, at an arrival into
    `in_progress`. The file is never written here (rule 3): the line names the
    file, what it holds and what R5 will demand, both read by R5's own readers.
    """
    if (kind != vocabulary.GRAIN_MILESTONE
            or cfg.version_at != vocabulary.VERSION_AT_START
            or vocabulary.category_of(cfg, kind, to) != vocabulary.IN_PROGRESS):
        return []
    want, _why = inventory.graded_release(cfg)
    held = inventory.shipped_version(cfg)
    if want is None or held == want:
        return []
    return [f'next: set {cfg.version_file} version {held or "(none)"} -> '
            f'{want} — R5 DRIFT until it does']


# --- #69: the gates a project declares for an arrival -------------------------
GRAIN_ENV = 'GRAIN'
# `make`'s own failure line says which target failed, which the WARN already
# names; the line worth showing is the recipe's.
_MAKE_NOISE = re.compile(r'^g?make(\[\d+\])?: \*\*\*')


def gate_lines(cfg: vocabulary.PmConfig, kind: str, to: str,
               gids: list[str]) -> list[str]:
    """Run each `[pm] arrival_gates` target for `kind` ONCE, with
    `GRAIN=<id>[,<id>…]`, and return one `WARN` line per failing target.

    Asked after the writes, of the grains that MOVED into a todo or
    in_progress state. A failure never refuses and never moves the exit code
    (D1, rule 9): `pm` moves and reports."""
    targets = cfg.arrival_gates.get(kind, ())
    if (not targets or not gids or vocabulary.category_of(cfg, kind, to)
            not in (vocabulary.TODO, vocabulary.IN_PROGRESS)):
        return []
    env = dict(os.environ)
    env[GRAIN_ENV] = ','.join(gids)
    lines = []
    for target in targets:
        try:
            done = spawn.run(('make', target), cwd=str(cfg.root), env=env,
                             capture_output=True, text=True)
        except OSError as err:
            lines.append(f'WARN arrival gate {target}: could not run make '
                         f'({err})')
            continue
        apply.outside_wrote()   # the target may have written the tree
        if done.returncode == 0:
            continue
        said = [line.strip() for line in
                (done.stdout or '').splitlines() + (done.stderr or '').splitlines()
                if line.strip() and not _MAKE_NOISE.match(line.strip())]
        lines.append(f'WARN arrival gate {target} failed for {env[GRAIN_ENV]} '
                     f'(exit {done.returncode}): '
                     f'{said[-1] if said else "no output"}')
    return lines


def run_gates(cfg: vocabulary.PmConfig, kind: str, to: str,
              gids: list[str]) -> None:
    """`gate_lines`, said on STDERR beside the rest of the arrival."""
    for line in gate_lines(cfg, kind, to, gids):
        _say(line)


def report(cfg: vocabulary.PmConfig, kind: str, gid: str, to: str,
           said: Said, answered: bool = False) -> dict:
    """Say what this arrival has to say, and hand back the row it emitted, in
    read order: what the belt asks, what is installed, the fork, then the
    tree. Nothing at all when there is nothing to say."""
    node = vocabulary.arrival_at(cfg, kind, to)
    nxt = derive_next(cfg, kind, to)
    have = capabilities(cfg, node)
    # `[pm] breadcrumbs = false` silences the PROSE only; the ROW carries the
    # same derivation either way.
    if cfg.breadcrumbs:
        if nxt is not None:
            _say(f'next: `{nxt.action}` asks {", ".join(nxt.checks)}')
        for capability in have:
            _say(capability.line)
        for line in remote_lines(cfg, kind, to):
            _say(line)
        for line in version_lines(cfg, kind, to):
            _say(line)
    # Asking again for a disposition the census counts is the nag, not a fork.
    for line in ([] if answered else fork_lines(cfg, node, gid, said)):
        _say(line)
    crossed = crossing(cfg, kind, gid)
    if crossed:
        _say(crossed)
    open_work = census(cfg)
    if open_work:
        _say('')
        _say(open_work.line)
    return ledger.leave_row(gid, to, nxt, have, said)
