"""check pm — the active PM tree's status drift (D), integrity (V), usage (U) and plan (R).

D: statuses that contradict each other. V: frontmatter, and bindings that
resolve to a grain of the right kind. U: a declared state or capability the
tree never used or recorded. R: the plan and the releases held to each other.

Every rule asks a CATEGORY (`todo`/`in_progress`/`done`), never a word, off the same
predicates in `repo/pm/vocabulary` that `pm` writes with. Which rules run is `[pm] checks`
(default: D1/D2/D4/D5/D6/D11/D12/D15 + U1 + V1/V4/V5/V7; U2/U4, D9/D10 and
R1/R2/R3/R4/R5/R6 are opt-in). A declared list REPLACES the default, and a
stock-on rule it omits is named on the ROSTER line. D3 retired INTO D11 and D8
into R5; a roster still naming a retired id is refused at exit 2, told which
rule replaces it. `pm vocabulary` lists every rule id `[pm] checks` may name.

NEVER GATED by `[pm] checks` (each FAILs, naming the path):
  a document that declares an `id:` and sits in no pool; a retired field
  (`fix_milestone:`, `caught_in:`) on any grain — delete the line by hand, since
  no `pm` verb removes a field; a tree holding BOTH a pool with a document
  and milestone directories, named before the zero-milestone verdict it causes
  ROSTER  a declared `[pm] checks` omitting a stock-on rule: one counted line
      naming each, never the exit code — the roster is the project's own

DRIFT (each FAILs, naming the path):
  D1  a `reviewed:` pointer naming a file that is not there
  D4  a status the project never declared, for any grain kind
  D11 a parent in `done` over a child that is not, every level off `BINDS_TO`.
      `pm remove` is the opt-out
  D12 (WARN) a grain in `done` carrying no `changelog:` and no `none` — the
      release belt refuses on it; this names it while there is time to write one
  D15 a `[verify]` section `dispatch`, `integrate` and `verify` would refuse at
      exit 2 — a chained rung, a retired key — quoting their reader's own
      message, so the commit that made it fails rather than the next run. No
      `[verify]` at all says nothing: a tree may have no ladder.
  R1  an `order` entry naming no milestone in the tree (WARN); a milestone on
      no plan is UNSEQUENCED, a counted line
  R3  two milestones claiming one `version:`
  R4  history is a prefix — a shipped release sitting after an unshipped one
  R5  the version file equals the CURRENT release in `order` ([pm] version_at)
  R6  an entry behind the last shipped one whose milestone never closed, and a
      `done` milestone that is on no plan
  D9/D10  an `in_progress` milestone declares a `branch:`, and it is not the
      mainline (`[repo_hygiene] mainline`, `origin/`-stripped)
WARN (a line, never the exit code; both grains and both categories named):
  D2  a feature in `todo` while all its stories are `done`
  D5  a story out of `todo` under a feature still in it
  D6  a milestone in `todo` whose features are all `done`
  U1  a DECLARED state no grain of that kind holds now AND no ledger `status`
      (`from`/`to`) or `disposition` (`state`) row names — ONE line for every
      kind, each naming those states beside its count held; a row naming an id
      no grain declares (retired, or renamed — `pm rename` does not rewrite the
      ledger) has no kind to read and is skipped, counted
  U2  the ledger couriers are wired in `.claude/settings.json` and the tree holds
      no row at all — recording that goes nowhere, which is silent by construction
  U4  the couriers are wired and the LAST hook-written row is named with its age —
      a WARN when there has never been one, a counted RECORDING line when there
      has. Status, decision and gate rows are written from inside this checkout
      and are not evidence a courier ran, which is why U2 passes over a tree that
      records no dispatch at all
  READY  an IN_PROGRESS grain with an empty scaffolded section (`## Ship criterion`,
         `## Acceptance criteria`, `## Proof budget`), a missing or empty line
         `[pm.required.<kind>] lines` declares, no stories, no `owner:`, no
         `branch:`, or (a milestone) no `handoff.md` — never auto-minted, so
         `pm new handoff <id>` is the fix — or `reconcile: forward` and no
         `reconcile.md` (`pm new reconcile <id>`). A CLOSED grain's gaps are COUNTED on
         one line rather than named: its criterion is nobody's next action, and
         that was 45 of this repo's 57 warnings
  CLOSE  a close the tree is ready for, never gated by `[pm] checks`: one
         counted line per kind, naming the grains and the status write that
         closes each — in-progress stories whose `done:` line names a commit,
         and in-progress features whose stories are all in `done`. The
         verdict line ends `; N close(s) ready to run — <command>`. A count,
         never the exit code
  R2  the BACKLOG census — milestones on no plan that declare no `version:`
  LOCAL  `<roadmap>/ledger.local.jsonl` exists and no `.gitignore` line covers
         it, so every gated commit leaves it untracked — `pm init` adds the
         line. Never gated by `[pm] checks`
INTEGRITY (each FAILs, naming the path; `pm validate` asks the same questions):
  V1  frontmatter is well-formed — every document declares an `id:` and a
      `status:`, and no two documents claim one id
  V4  refs resolve — `depends_on`, `consumed_by`, and a bug's `caused_by`;
      one to a milestone no longer in the tree, or to an id a `retire`
      row lists as removed, is UNVERIFIABLE (counted, never a finding)
  V5  the feature `depends_on` graph is acyclic
  V7  MEMBERSHIP and SEQUENCE, each in both directions. A binding naming a grain
      not in the tree or of the wrong kind FAILS; an `order` entry naming a grain
      its parent does not hold is DANGLING (FAIL), one naming no grain at all
      UNVERIFIABLE (WARN). An EMPTY binding is UNBOUND and a bound child in no
      `order` is UNSEQUENCED — COUNTED lines, never findings, because *nothing
      said* is a plan and *something wrong said* is drift

Archived milestones are out of scope; a zero census FAILS.
"""
from __future__ import annotations

import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import NamedTuple

from agentic_sdlc.repo import vehicle
from agentic_sdlc.repo.pm import inventory, reconcile, required, vocabulary

ID = vehicle.Slot('<id>')

# How many row kinds the 'what IS recorded' census names before the fix
# line; thirteen of them once pushed that fix behind 839 characters.
CENSUS_TOP = 3

# One word, so `check pm | grep never` is a consumer's whole reader.
NEVER = 'never'
# The third answer, dropped on the floor by a belt that branched on two of
# them. A PREFIX: what could not be read is named after it.
UNVERIFIABLE = 'UNVERIFIABLE'
# A row whose `ts` will not parse is not a row aged zero (rule 4): a ledger is
# `merge=union`, and rows arrive from other branches and other versions.
UNDATEABLE = 'at a timestamp this reader cannot parse'
# The harness's per-user override. `install-hooks` emits ABSOLUTE paths and a
# public repo must not commit a machine path, so the block belongs in a
# gitignored file — a reader of one file calls such a tree unwired.
AGENT_SETTINGS_LOCAL = '.claude/settings.local.json'
SETTINGS_FILES = (vocabulary.AGENT_SETTINGS, AGENT_SETTINGS_LOCAL)


def run() -> int:
    try:
        # THE one read-only scope: the walk under every rule is shared rather
        # than repeated per rule per grain, and the scope drops itself on a write.
        with inventory.reading_tree():
            return _run()
    except vocabulary.ConfigError as err:
        # EVERY defect, not the first, and the FLOW first among them: the flow
        # is read lazily, so a tree that declared none is refused at the first
        # category question, and a real adoption is wrong in more ways than one.
        try:
            defects = vocabulary.all_config_defects()
        except Exception:  # noqa: BLE001 - the collector must never mask the error
            defects = []
        for msg in defects or [str(err)]:
            print(f'[check:pm] ERROR — {msg}', file=sys.stderr)
        if len(defects) > 1:
            print(f'[check:pm] {len(defects)} config defect(s) — all of them '
                  f'are above, and the first one listed is the one that stops '
                  f'the most', file=sys.stderr)
        return 2


def _run() -> int:
    cfg = vocabulary.load()
    # Validated here, not in `vocabulary.load()`, so a stale rule id cannot take `pm status` down.
    stale = vocabulary.config_complaints(cfg)
    if stale:
        # The flow can be declared and the roster still stale; report the whole
        # set either way, in the same order.
        flow = vocabulary.missing_flow_defect()
        for msg in ([flow] if flow else []) + stale:
            print(f'[check:pm] ERROR — {msg}', file=sys.stderr)
        return 2
    findings: list[str] = []
    warnings: list[str] = []

    def report(msg: str) -> None:
        findings.append(msg)
        print(f'  DRIFT  {msg}')

    def warn(msg: str) -> None:
        warnings.append(msg)
        print(f'  WARN  {msg}')

    enabled = set(cfg.checks)
    print(f'[check:pm] scanning active PM tree ({cfg.roadmap_dir}/, '
          f'excluding {vocabulary.ARCHIVE_DIR_NAME}/)')

    # Never gated by `checks`, and BEFORE the zero-milestone verdict: a mixed
    # tree reads as its pools alone, so every nested milestone vanishes and
    # the verdict below would blame `roadmap_dir` for it (#84).
    _mixed_layout(cfg, report)
    found_milestones = inventory.milestones(cfg)
    if not found_milestones:
        print()
        print(f'[check:pm] FAIL — no milestones found under {cfg.roadmap_dir}/ '
              f'(wrong [pm] roadmap_dir, or an empty tree?)')
        return 1

    # Never gated by `checks`: this is the scan saying it found something it
    # cannot place.
    for stray in inventory.stray_documents(cfg):
        report(f'{cfg.rel(stray.path)} declares `id: '
               f'{stray.field(vocabulary.FIELD_ID)}` and sits in no '
               f'pool, so every reader walks past it — move it into '
               f'{cfg.rel(inventory.pool_dir(cfg, stray.field(vocabulary.FIELD_KIND) or vocabulary.GRAIN_MILESTONE))}/')
    _retired_fields(cfg, report)
    _omitted_stock_rules(cfg)

    # No readable `id:`, and two documents claiming one, are V1's and are
    # reported from `validate.run` below, so `pm validate` and this gate cannot
    # disagree about a file neither of them can key on.

    # Always walked for the census; reported only under D4.
    bug_findings, n_bugs = inventory.bug_status_findings(cfg)
    if 'D4' in enabled:
        for path, why in bug_findings:
            report(f'{cfg.rel(path)}: {why}')

    ready = _Ready(warn)
    n_features, n_stories, seen = _drift_walk(cfg, enabled, found_milestones,
                                              report,
                                              warn, ready)

    _unreached_self(cfg, enabled, seen, report, ready)
    _required_lines(cfg, ready)
    ready.report()
    closes = _close_ready_findings(cfg, warn)
    _containment(cfg, enabled, report)
    _changelog_answered(cfg, enabled, warn)
    _ladder_refused(enabled, report)
    _unbound_rows(cfg, enabled, report, warn)
    _flow_findings(cfg, enabled, report)
    _unused_states(cfg, enabled, warn)
    _recording_findings(cfg, enabled, warn)
    _hook_recording_findings(cfg, enabled, warn)
    _local_ledger_unignored(cfg, warn)
    _release_findings(cfg, enabled, report, warn)

    # --- V1-V7: structural + referential integrity ------------------------
    v_on = enabled & set(vocabulary.VALIDATE_CHECKS)
    v_census: dict = {}
    if v_on:
        from agentic_sdlc.repo.pm import validate as _validate
        v_findings, v_census = _validate.run(cfg, v_on)
        for msg in v_findings:
            report(msg)

    return _verdict(cfg, findings, warnings,
                    _census(cfg, len(found_milestones), n_features,
                            n_stories, n_bugs),
                    v_on, v_census, closes)


def _mixed_layout(cfg: vocabulary.PmConfig, report) -> None:
    """A tree holding BOTH a pool and milestone directories: one DRIFT line
    naming each. Every reader then reads the pools alone, so this is the real
    cause of whatever the tree reports as missing."""
    pools, mdirs = inventory.mixed_layout(cfg)
    if not pools:
        return
    shown = ', '.join(f'{cfg.rel(d)}/' for d in mdirs[:3])
    more = f' and {len(mdirs) - 3} more' if len(mdirs) > 3 else ''
    report(f'{cfg.roadmap_dir}/ holds BOTH layouts — pool(s) '
           f'{", ".join(f"{cfg.rel(p)}/" for p in pools)} and {len(mdirs)} '
           f'milestone director(ies) ({shown}{more}) — every reader reads the '
           f'pools alone, so each nested grain is invisible; move the pooled '
           f'document(s) under their milestone directory, or finish the '
           f'migration to pools')


# D2's and D6's shared tail; neither rule has an opinion about which state is next.
ADVANCE_IT = 'advance it (`done` is the LAST state, not the next one)'


def _cat(cfg: vocabulary.PmConfig, kind: str, status: str) -> str:
    """The category a WARN line prints beside a word, or 'undeclared'."""
    return vocabulary.category_of(cfg, kind, status) or 'undeclared'


class _Ready:
    """READY's two audiences: a gap on an `in_progress` grain can still be
    acted on, so it is NAMED; one on a closed grain cannot — a criterion is a
    promise about work that has not happened — so it is COUNTED. D12 drew this
    line first, for the same 351-of-359.
    """

    def __init__(self, warn) -> None:
        self._warn = warn
        self.named = self.counted = self.live = self.closed = 0

    def grading(self, cfg: vocabulary.PmConfig, kind: str, status: str) -> bool | None:
        """True while the grain can still act, False once it has closed, None
        in `todo` — where nothing is asked and nothing is counted."""
        category = vocabulary.category_of(cfg, kind, status)
        if category is None or category == vocabulary.TODO:
            return None
        live = category == vocabulary.IN_PROGRESS
        self.live += live
        self.closed += not live
        return live

    def gap(self, live: bool, msg: str) -> None:
        if live:
            self.named += 1
            self._warn(msg)
        else:
            self.counted += 1

    def report(self) -> None:
        # Printed at zero too: a family that graded nothing has to say so, and
        # this count is what makes the narrowing above visible (rule 4).
        print(f'  READY  {self.named} gap(s) named on {self.live} '
              f'{vocabulary.IN_PROGRESS} grain(s); {self.counted} on {self.closed} '
              f'closed grain(s) counted rather than named — a closed grain\'s '
              f'scaffolded section is nobody\'s next action (READY)')


def _feature_self(cfg: vocabulary.PmConfig, view, ready: _Ready) -> None:
    """The READY warnings a feature earns on its OWN document."""
    live = ready.grading(cfg, vocabulary.GRAIN_FEATURE, view.status)
    if live is None:
        return
    frel = cfg.rel(view.path)
    if view.total == 0:
        ready.gap(live, f'feature {view.fid} is {view.status!r} with no '
                        f'stories — past todo, and nothing to build  [{frel}]')
    why = view.feature.section_defect(inventory.SHIP_HEADING)
    if why:
        ready.gap(live, f'feature {view.fid} is {view.status!r} and {why} — '
                        f'past todo, and nothing says what done means  [{frel}]')
    # The anti-bloat contract, never verified to exist until here: an empty
    # proof budget is how a feature ships twice its budget with nobody able to
    # say so.
    why = view.feature.section_defect(inventory.PROOF_HEADING)
    if why:
        ready.gap(live, f'feature {view.fid} is {view.status!r} and {why} — '
                        f'past todo, and nothing says what it should COST  '
                        f'[{frel}]')


def _story_self(cfg: vocabulary.PmConfig, story, sid: str, sstat: str,
                ready: _Ready) -> None:
    """The READY warnings a story earns on its OWN document."""
    srel = cfg.rel(story.path)
    live = ready.grading(cfg, vocabulary.GRAIN_STORY, sstat)
    if live is None:
        return
    why = story.section_defect(inventory.ACCEPTANCE_HEADING)
    if why:
        ready.gap(live, f'story {sid} is {sstat!r} and {why} — past todo, and '
                        f'nothing says what must be true  [{srel}]')
    if live and not story.field(vocabulary.FIELD_OWNER):
        # A LIVE BUG, not a tidy-up: two modules READ `owner:` and nothing
        # asked whether the claim had set it (`pm-execution.md` step 1).
        ready.gap(True, f'story {sid} is {sstat!r} ({vocabulary.IN_PROGRESS}) and '
                        f'carries no owner: — somebody is working on it and '
                        f'the tree cannot say who  [{srel}]')


def _required_lines(cfg: vocabulary.PmConfig, ready: _Ready) -> None:
    """READY for `[pm.required.<kind>] lines`: a declared line missing or
    empty on a grain past `todo` — named on an `in_progress` grain, counted on
    a closed one. Walks nothing for a kind that declares none, so a tree with
    no `[pm.required.*]` prints what it printed before."""
    for kind, prefixes in cfg.required_lines.items():
        grains = (inventory.milestones(cfg) if kind == vocabulary.GRAIN_MILESTONE
                  else inventory.every_grain(cfg, kind))
        for grain in grains:
            status = grain.field(vocabulary.FIELD_STATUS)
            category = vocabulary.category_of(cfg, kind, status)
            if category is None or category == vocabulary.TODO:
                continue
            try:
                text = grain.text
            except (OSError, UnicodeDecodeError):
                continue
            for why in required.defects(text, prefixes):
                ready.gap(category == vocabulary.IN_PROGRESS,
                          f'{kind} {grain.gid or cfg.rel(grain.path)} is '
                          f'{status!r} and {why} — '
                          f'{vocabulary.required_key(kind)} declares it  '
                          f'[{cfg.rel(grain.path)}]')


def _unreached_self(cfg: vocabulary.PmConfig, enabled: set[str], seen: set[str],
                    report, ready: _Ready) -> None:
    """Every SELF rule, for the grains the descent did not visit.

    **`seen` is RECORDED, never inferred.** "Does this binding resolve" gets a
    story under an UNBOUND feature wrong — its binding resolves and the descent
    still never reaches it, so it fell between both passes at exit 0. SELF
    rules only: D5 and D11 need a parent to compare against.
    """
    if not inventory.is_pooled(cfg):
        return
    for kind in (vocabulary.GRAIN_FEATURE, vocabulary.GRAIN_STORY):
        for grain in inventory.every_grain(cfg, kind):
            if not grain.gid or grain.gid in seen:
                continue
            rel = cfg.rel(grain.path)
            status = grain.field(vocabulary.FIELD_STATUS)
            if 'D4' in enabled:
                reason = inventory.undeclared_status(cfg, kind, status)
                if reason:
                    report(f'{kind} {grain.gid}: {reason}  [{rel}]')
            if kind == vocabulary.GRAIN_FEATURE:
                if 'D1' in enabled:
                    # A fact about ONE document, and it was in the descent only.
                    reason = inventory.drift_dangling_record(cfg, grain.gid)
                    if reason:
                        report(f'feature {grain.gid}: {reason} — point it at a '
                               f'real file or remove the field  [{rel}]')
                _feature_self(cfg, inventory.feature_view(cfg, grain), ready)
            else:
                _story_self(cfg, grain, grain.gid, status, ready)


def _drift_walk(cfg: vocabulary.PmConfig, enabled: set[str], found_milestones,
                report, warn, ready: _Ready) -> tuple[int, int, set[str]]:
    """D1-D6 over every grain the descent reaches, plus the READY warnings.

    The third return is the ids it VISITED, because `_unreached_self` must not
    have to infer them.
    """
    n_features = 0
    n_stories = 0
    seen: set[str] = set()

    for milestone in found_milestones:
        mfile = milestone.path
        mid = milestone.field(vocabulary.FIELD_ID)
        mstat = milestone.field(vocabulary.FIELD_STATUS)
        m_cat = vocabulary.category_of(cfg, vocabulary.GRAIN_MILESTONE, mstat)
        m_live = ready.grading(cfg, vocabulary.GRAIN_MILESTONE, mstat)
        # Read on EVERY milestone, so a malformed value is exit 2 by name
        # whatever the state (rule 9).
        forward = reconcile.declared(cfg, milestone)

        if 'D4' in enabled:
            reason = inventory.undeclared_status(cfg, vocabulary.GRAIN_MILESTONE, mstat)
            if reason:
                report(f'milestone {mid}: {reason}  [{cfg.rel(mfile)}]')

        if m_live is not None:
            if not milestone.field('branch'):
                ready.gap(m_live, f'milestone {mid} is {mstat!r} with no '
                                  f'branch: — past todo, and a fresh checkout '
                                  f'cannot find where its work lives  '
                                  f'[{cfg.rel(mfile)}]')
            why = milestone.section_defect(inventory.SHIP_HEADING)
            if why:
                ready.gap(m_live, f'milestone {mid} is {mstat!r} and {why} — '
                                  f'past todo, and nothing says what done '
                                  f'means  [{cfg.rel(mfile)}]')
            # Never auto-minted, so its ABSENCE is the signal. IN_PROGRESS only:
            # a handoff is a cold-start aid, so warning on `done` would fire
            # once per historical milestone on every consumer's tree.
            handoff = inventory.shared_doc(cfg, mfile, vocabulary.HANDOFF_FILE_NAME)
            if m_live and not handoff.is_file():
                ready.gap(True, f'milestone {mid} is {mstat!r} with no '
                                f'{vocabulary.HANDOFF_FILE_NAME} — past todo, and a '
                                f'cold session has nowhere to start; `pm new '
                                f'handoff {mid}` mints one  '
                                f'[{cfg.rel(handoff)}]')
            # #92: an opt-in record, absent while the milestone can still act.
            # Its completeness is `dispatch --reconcile`'s to render.
            record = reconcile.record_path(cfg, milestone)
            if m_live and forward and not record.is_file():
                ready.gap(True, f'milestone {mid} is {mstat!r} with '
                                f'`{vocabulary.FIELD_RECONCILE}: '
                                f'{vocabulary.RECONCILE_FORWARD}` and no '
                                f'{vocabulary.RECONCILE_FILE_NAME} — `pm new '
                                f'reconcile {mid}` mints one  '
                                f'[{cfg.rel(record)}]')

        views = [inventory.feature_view(cfg, feature)
                 for feature in inventory.feature_grains(cfg, mid)]
        # D6's census. The per-feature half went to D11 with D3.
        finished = vocabulary.holds(cfg, vocabulary.GRAIN_FEATURE,
                               ((v.fid, v.status) for v in views),
                               vocabulary.DONE_CATEGORY)
        for view in views:
            frel = cfg.rel(view.path)
            seen.add(view.fid)
            n_features += 1
            n_stories += view.total

            if 'D4' in enabled:
                reason = inventory.undeclared_status(cfg, vocabulary.GRAIN_FEATURE,
                                                 view.status)
                if reason:
                    report(f'feature {view.fid}: {reason}  [{frel}]')

            if 'D1' in enabled:
                reason = inventory.drift_dangling_record(cfg, view.fid)
                if reason:
                    report(f'feature {view.fid}: {reason} — point it at a real '
                           f'file or remove the field  [{frel}]')

            _feature_self(cfg, view, ready)

            for story in view.stories:
                sid = story.field(vocabulary.FIELD_ID)
                seen.add(sid)
                sstat = story.field(vocabulary.FIELD_STATUS)
                srel = cfg.rel(story.path)
                if 'D4' in enabled:
                    reason = inventory.undeclared_status(cfg, vocabulary.GRAIN_STORY,
                                                     sstat)
                    if reason:
                        report(f'story {sid}: {reason}  [{srel}]')
                _story_self(cfg, story, sid, sstat, ready)
                if 'D5' in enabled and inventory.drift_ahead_of_parent(
                        cfg, sstat, view.status):
                    warn(f'story {sid} is {sstat!r} '
                         f'({_cat(cfg, vocabulary.GRAIN_STORY, sstat)}) but its feature '
                         f'{view.fid} is still {view.status!r} '
                         f'({_cat(cfg, vocabulary.GRAIN_FEATURE, view.status)}) — the story '
                         f'is at work and the feature says it has not '
                         f'started (two places in this tree disagree, D5)'
                         f'  [{srel}]')

            if 'D2' in enabled:
                reason = inventory.drift_stalled(cfg, view)
                if reason:
                    warn(f'feature {view.fid}: {reason} '
                         f'({_cat(cfg, vocabulary.GRAIN_FEATURE, view.status)}) — all '
                         f'{view.total} stories are {vocabulary.DONE_CATEGORY}; '
                         f'{ADVANCE_IT} (D2)  [{frel}]')

        if ('D6' in enabled and m_cat == vocabulary.TODO
                and finished.counted > 0 and finished):
            warn(f'milestone {mid} is {mstat!r} ({m_cat}) but all '
                 f'{finished.counted} features are {vocabulary.DONE_CATEGORY} — '
                 f'you finished the features and the milestone still calls '
                 f'itself {mstat!r}; {ADVANCE_IT} (D6)  [{cfg.rel(mfile)}]')

    return n_features, n_stories, seen


class CloseReady(NamedTuple):
    """The closes the tree is READY to write, as `(id, status)` pairs."""

    stories: list[tuple[str, str]]      # a `done:` line naming a commit, not in `done`
    closable: list[tuple[str, str]]     # in_progress, every story in `done`


# `done: <hash(es)> — <what shipped>`, tolerant of case and whitespace: the
# shape asked is "evidence was left". A commit hash or the literal `in-place`.
EVIDENCE_LINE = re.compile(r'^\s*done\s*:\s*(?P<body>\S.*)$', re.IGNORECASE)
EVIDENCE_LANDED = re.compile(r'\b(?:[0-9a-fA-F]{7,40}|in-place)\b',
                             re.IGNORECASE)


def evidence_in(text: str) -> bool:
    """A story's text carries a `done:` line naming a commit and what shipped."""
    for raw in text.split('\n'):
        line = EVIDENCE_LINE.match(raw)
        body = line.group('body') if line else ''
        if EVIDENCE_LANDED.search(body) and EVIDENCE_LANDED.sub(
                '', body).strip(' \t—–-:;,.'):
            return True
    return False


def close_ready(cfg: vocabulary.PmConfig) -> CloseReady:
    """The closes a status write would make now: in-progress stories whose
    `done:` line names a commit, and in-progress features whose stories are
    all in `done`. Read only; its own read scope, for `pm status`."""
    with inventory.reading_tree():
        ready = CloseReady([], [])
        for story in inventory.every_grain(cfg, vocabulary.GRAIN_STORY):
            status = story.field(vocabulary.FIELD_STATUS)
            if (not story.gid or vocabulary.category_of(
                    cfg, vocabulary.GRAIN_STORY, status)
                    != vocabulary.IN_PROGRESS):
                continue
            try:
                text = story.text
            except (OSError, UnicodeDecodeError):
                continue    # unreadable is no answer; V1 owns that finding
            if evidence_in(text):
                ready.stories.append((story.gid, status))
        for feature in inventory.every_grain(cfg, vocabulary.GRAIN_FEATURE):
            view = inventory.feature_view(cfg, feature)
            if (view.fid and view.total and view.done_n == view.total
                    and vocabulary.category_of(
                        cfg, vocabulary.GRAIN_FEATURE, view.status)
                    == vocabulary.IN_PROGRESS):
                ready.closable.append((view.fid, view.status))
        return ready


def close_command(cfg: vocabulary.PmConfig, kind: str, *ids: str) -> str:
    """`pm <kind> <done-state> <id>` — the close is a status write."""
    state = vocabulary.flow_of(cfg, kind).by_category[
        vocabulary.DONE_CATEGORY][0]
    return vehicle.command('pm', kind, state, *ids)


# The verdict line's close clause: `; <n> close(s) ready to run — <command>`.
# The `[CHECK]` line `make check` prints reads it by this shape (rule 6).
CLOSE_CLAUSE = '; {n} close(s) ready to run — {commands}'
SHOWN_MAX = 5


def close_clause(cfg: vocabulary.PmConfig, ready: CloseReady) -> str:
    """The verdict line's clause for the ready closes, one command per id
    clipped at `SHOWN_MAX`, or '' when there are none."""
    commands = []
    for kind, pairs in ((vocabulary.GRAIN_STORY, ready.stories),
                        (vocabulary.GRAIN_FEATURE, ready.closable)):
        ids = [gid for gid, _ in pairs]
        commands += [close_command(cfg, kind, gid) for gid in ids[:SHOWN_MAX]]
        if len(ids) > SHOWN_MAX:
            commands.append(f'(+{len(ids) - SHOWN_MAX} more)')
    if not commands:
        return ''
    return CLOSE_CLAUSE.format(n=len(ready.stories) + len(ready.closable),
                               commands=' and '.join(commands))


def _close_ready_findings(cfg: vocabulary.PmConfig, warn) -> str:
    """CLOSE — one counted line per kind of ready close, naming the grains and
    the status write that closes each. Never the exit code, and never gated by
    `[pm] checks`. Returns the verdict line's close clause."""
    ready = close_ready(cfg)
    done = vocabulary.DONE_CATEGORY

    def named(pairs: list[tuple[str, str]]) -> str:
        return ', '.join(f'{gid} ({status!r})' for gid, status in pairs)

    if ready.stories:
        warn(f'{len(ready.stories)} story/ies ready to close — each carries a '
             f'`done:` line naming a commit and is not in `{done}`: '
             f'{named(ready.stories)}; next: `'
             f'{close_command(cfg, vocabulary.GRAIN_STORY, ID)}`, one per '
             f'story (CLOSE)')
    if ready.closable:
        warn(f'{len(ready.closable)} feature(s) ready to close — every story '
             f'in `{done}`: {named(ready.closable)}; next: `'
             f'{close_command(cfg, vocabulary.GRAIN_FEATURE, ID)}` (CLOSE)')
    return close_clause(cfg, ready)


def _unused_states(cfg: vocabulary.PmConfig, enabled: set[str], warn) -> None:
    """U1 — a state the project DECLARED that no grain holds now and no ledger
    row names.

    A WARN with the count, never a finding: a tree mid-adoption legitimately has
    unused states, and a rule that reddens every fresh consumer is undone within
    a version. What it buys is the fact staying VISIBLE after the install
    scrolls away.

    It says what it READ and stops there (#30, rule 9): "a flow the project is
    not running" was an inference from a snapshot, and one consumer narrowed its
    ladder over it while the ledger held the rows saying otherwise.

    ONE line for every kind: three near-identical paragraphs saying one sentence
    about `[pm.states.*]` is how a line somebody could act on gets scrolled past.
    """
    if 'U1' not in enabled:
        return
    history = inventory.state_history(cfg)
    clauses, unused_total, declared_total = [], 0, 0
    for kind in vocabulary.FLOW_KINDS:
        counts = history.usage.get(kind)
        if not counts:
            continue
        unused = history.never(kind)
        if not unused or len(unused) == len(counts):
            # All unused means the tree holds no grain of this kind — a
            # different fact, and not this rule's to report.
            continue
        unused_total += len(unused)
        declared_total += len(counts)
        clauses.append(f'{kind}: {len(counts) - len(unused)} of {len(counts)} '
                       f'held, {", ".join(unused)} never held')
    if not clauses:
        return
    # No row COUNT: a row naming a state already held adds no fact, and the
    # line must not move for it (`test_pm_ledger`'s byte-identity case).
    read = ('read from every grain\'s current status plus the ledger\'s '
            'status and disposition rows')
    # Retired or renamed is written nowhere, so both are said (M1, rule 9).
    placed = ''
    if history.skipped:
        placed = ' it could place'
        read += (f', {history.skipped} ledger row(s) naming '
                 f'{inventory.UNPLACED_ID} skipped')
    if history.unreadable:
        read += (f', {len(history.unreadable)} ledger(s) unreadable and not '
                 f'read ({", ".join(history.unreadable)})')
    warn(f'{unused_total} of {declared_total} declared state(s) are held by no '
         f'grain and named by no ledger row{placed} — {"; ".join(clauses)} — '
         f'{read}; `[pm.states.<kind>]` declares each one (U1)')


# --- the RECORDING family (U2/U4) ---------------------------------------------
# One question — did anything land — asked of the ledgers (see the U2/U4
# entries above). They share the walk below because a rule that opened the same
# files a second time would answer off a different read than the rule beside it.
#
# **Every one of them READS.** None writes a probe row to find out, because a
# gate that mutates to measure is a gate that lies about what it measured.


def _ledger_rows(cfg: vocabulary.PmConfig) -> tuple[list[tuple[Path, dict]], list[str]]:
    """An unreadable or unparseable ledger is NEITHER answer — it is named and
    the scan continues, so one damaged file cannot make the tree look silent.
    """
    from agentic_sdlc.repo.pm import ledger
    rows: list[tuple[Path, dict]] = []
    unreadable: list[str] = []
    for path in ledger.ledger_paths(cfg):
        if not path.is_file():
            continue
        try:
            rows.extend((path, row.data) for row in ledger.read_rows(path))
        except ledger.LedgerError:
            unreadable.append(cfg.rel(path))
    return rows, unreadable


class Wiring(NamedTuple):
    """Which couriers a settings file REGISTERS, and which file said so.

    PUBLIC: `telemetry-live` asks this too, and two readers of one config is
    how a belt and a gate come to disagree."""

    couriers: tuple[str, ...]   # the couriers a `hooks` entry actually fires
    where: str                  # the settings file(s) that fire them
    unread: str                 # why a settings file could not be read


def _settings_couriers(path: Path) -> tuple[tuple[str, ...], str]:
    """(the couriers this one file registers, why it could not be read).

    The reader is `hook_settings.settings_commands`, the one reader of a
    settings file; two readers of one settings file is the pair this
    milestone kept finding."""
    from agentic_sdlc.repo import hook_settings
    commands, why = hook_settings.settings_commands(path)
    return tuple(sorted(name for name in vocabulary.LEDGER_COURIERS
                        if any(name in command for command in commands))), why


def wired_couriers(root: Path) -> Wiring:
    """Which ledger couriers this checkout's settings files fire.

    **No settings file at all is an empty tuple, not a defect** — a tree that
    wires nothing opted out (0.4.0/D5). A ROOT, not a config: the belt asks
    before it has resolved a PM tree."""
    found: set[str] = set()
    where: list[str] = []
    unread: list[str] = []
    for rel in SETTINGS_FILES:
        couriers, why = _settings_couriers(root / rel)
        if why:
            unread.append(f'{rel} could not be read ({why})')
        elif couriers:
            found.update(couriers)
            where.append(rel)
    return Wiring(tuple(sorted(found)), ' and '.join(where),
                  '; '.join(unread))



def _age_of(row: dict) -> str:
    """`3h ago`, or the named non-answer for a row this reader cannot date."""
    from agentic_sdlc.repo.pm import ledger
    when = ledger.parse_ts(row.get(ledger.TS_FIELD))
    if when is None:
        return UNDATEABLE
    # Clamped: a row stamped in the future is a clock disagreement, and
    # rendering it as a negative age would read as a defect in this line.
    seconds = max(0, int((datetime.now(timezone.utc) - when).total_seconds()))
    return f'{ledger.human_duration(seconds)} ago'


def _recording_span(rows: list[tuple[Path, dict]]) -> str:
    """How long `never` has been true, off the OLDEST row these ledgers hold:
    five milestones and one afternoon read alike. No stamp, no number."""
    from agentic_sdlc.repo.pm import ledger
    stamps = [when for when in (ledger.parse_ts(row.get(ledger.TS_FIELD))
                                for _path, row in rows) if when is not None]
    if not stamps:
        return ''
    seconds = max(0, int((datetime.now(timezone.utc)
                          - min(stamps)).total_seconds()))
    return (f' in the {ledger.human_duration(seconds)} these ledgers have '
            f'been recording')


def _kind_of(row: dict) -> str:
    """The row's `kind`, or '' — type-checked, see `UNDATEABLE` above."""
    from agentic_sdlc.repo.pm import ledger
    kind = row.get(ledger.KIND_FIELD)
    return kind if isinstance(kind, str) else ''


def _kind_census(rows: list[tuple[Path, dict]], top: int = 0) -> str:
    """`'2 status, 1 gate'`, most-seen first — what the tree DID record, said
    beside what it did not. An unreadable kind is counted, never dropped.
    `top` caps the names and rolls the tail into a count — a thirteen-kind
    census was most of a warning nobody finished reading."""
    counts: dict[str, int] = {}
    for _path, row in rows:
        kind = _kind_of(row) or '(no kind)'
        counts[kind] = counts.get(kind, 0) + 1
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    tail = ranked[top:] if top else []
    named = ', '.join(f'{n} {kind}' for kind, n in (ranked[:top] if top
                                                    else ranked))
    if not tail:
        return named
    return (f'{named} and {sum(n for _kind, n in tail)} row(s) across '
            f'{len(tail)} more kind(s)')


class Recording(NamedTuple):
    """What this tree's ledgers say about rows a COURIER wrote.

    PUBLIC, because `adopt`'s `telemetry-live` reports the same fact: two
    readers of it is how a belt and a gate come to disagree.
    """

    last: dict                      # the newest hook-written row, or {}
    where: str                      # the ledger it sits in, repo-relative
    written: int                    # how many rows a courier wrote
    total: int                      # how many rows the ledgers hold at all
    unreadable: tuple[str, ...]     # the ledgers this could not read


def hook_recording(cfg: vocabulary.PmConfig) -> Recording:
    """Every ledger in the tree, read for the LAST row a courier wrote.

    Ordered by the row's own `ts`, never the file's mtime or line order: a
    ledger is merged `union`, so the last line is not the last event in time.
    """
    from agentic_sdlc.repo.pm import ledger
    rows, unreadable = _ledger_rows(cfg)
    written = [(path, row) for path, row in rows if _hook_written(row)]
    if not written:
        return Recording({}, '', 0, len(rows), tuple(unreadable))
    path, last = max(written,
                     key=lambda pair: str(pair[1].get(ledger.TS_FIELD, '')))
    return Recording(last, cfg.rel(path), len(written), len(rows),
                     tuple(unreadable))


def recording_phrase(rec: Recording) -> str:
    """`'dispatch, 3h ago'`, `'never'`, or why neither could be answered — the
    sentence every surface that reports recording prints, spelled once."""
    if rec.unreadable:
        return (f'{UNVERIFIABLE} ({", ".join(rec.unreadable)} could not be '
                f'read)')
    if not rec.written:
        return NEVER
    return f'{_kind_of(rec.last)}, {_age_of(rec.last)}'


def _tree_has_a_row(cfg: vocabulary.PmConfig) -> tuple[bool, list[str]]:
    """(does any ledger hold a row, the ledgers this could not read).

    Both homes (0.4.0/D3), and existence is not enough — an empty file is what
    a courier leaves when it created the file and then refused the row. **An
    unreadable ledger is neither answer**, so it is named and the scan goes on.

    Raw text rather than `_ledger_rows`: a line this package cannot parse is
    still something a courier wrote, and U2 asks whether anything landed.
    """
    from agentic_sdlc.repo.pm import ledger
    paths = ledger.ledger_paths(cfg)
    found, unreadable = False, []
    for path in paths:
        if not path.is_file():
            continue
        try:
            if path.read_text(encoding='utf-8').strip():
                found = True
        except (OSError, UnicodeDecodeError):
            unreadable.append(cfg.rel(path))
    return found, unreadable


def _local_ledger_unignored(cfg: vocabulary.PmConfig, warn) -> None:
    """LOCAL — the gitignored ledger exists and nothing ignores it (#48, 0.12.0
    review m7). A consumer who bumps without re-running `pm init` gets an
    untracked file after every gated commit, and nothing said so. Reads each
    `.gitignore` from the root down to the file's directory as TEXT — rule 2,
    no `git check-ignore` — last matching line wins, `!` included."""
    from agentic_sdlc.repo.pm import ledger
    path = ledger.local_path(cfg.roadmap)
    if not path.is_file():
        return
    try:
        rel = path.relative_to(cfg.root)
    except ValueError:
        return
    ignored = False
    for depth in range(len(rel.parts)):
        base = cfg.root.joinpath(*rel.parts[:depth])
        below = '/'.join(rel.parts[depth:])
        try:
            text = (base / '.gitignore').read_text(encoding='utf-8')
        except (OSError, UnicodeDecodeError):
            continue
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            negated = line.startswith('!')
            if _ignore_matches(line.lstrip('!'), below):
                ignored = not negated
    if not ignored:
        warn(f'{cfg.rel(path)} exists and no .gitignore line covers it, so '
             f'every commit whose hook runs the gates leaves it untracked — '
             f're-run `pm init` (`{vehicle.command("pm", "init")}`), which '
             f'adds the line and changes nothing already there')


def inputs():
    """What this gate reads, for `check all`'s reuse (#98): every directory
    and file the PM config names, devkit.toml, both settings files, the local
    ledger and every `.gitignore` between the root and it."""
    from agentic_sdlc.core.project import CONFIG_NAME
    from agentic_sdlc.repo.pm import ledger
    from agentic_sdlc.repo.verify.gates import Inputs, pm_scope
    cfg = vocabulary.load()
    local = ledger.local_path(cfg.roadmap)
    also = [*SETTINGS_FILES, cfg.rel(local)]
    parts = local.parent.relative_to(cfg.root).parts
    also.extend('/'.join((*parts[:depth], '.gitignore'))
                for depth in range(len(parts) + 1))
    # Each `reviewed:` pointer is read by D1, and a record may sit outside
    # `review_dir`: one removed there must re-run this gate.
    from agentic_sdlc.core.config import pointer_escapes
    for feature in inventory.every_grain(cfg, vocabulary.GRAIN_FEATURE):
        pointer = feature.field('reviewed')
        if pointer and pointer != 'null' and not pointer_escapes(pointer):
            also.append(pointer)
    return Inputs(scope=(*pm_scope(cfg), CONFIG_NAME), also=tuple(also))


def _ignore_matches(pattern: str, rel: str) -> bool:
    """Does one `.gitignore` pattern cover `rel` (a path below that file)?
    The gitignore shapes that matter here: anchored or not by a slash, a
    trailing `/` for a directory, and `*`/`**` globs."""
    import fnmatch
    parts = rel.split('/')
    anchored = '/' in pattern.rstrip('/')
    pattern = pattern.lstrip('/')
    directory = pattern.endswith('/')
    pattern = pattern.rstrip('/')
    # Every ancestor directory is a candidate as well as the file itself: an
    # ignored directory takes everything under it.
    candidates = ['/'.join(parts[:n]) for n in range(1, len(parts))]
    if not directory:
        candidates.append(rel)
    for one in candidates:
        if anchored:
            if fnmatch.fnmatchcase(one, pattern) or (
                    pattern.startswith('**/')
                    and fnmatch.fnmatchcase(one, pattern[3:])):
                return True
        elif fnmatch.fnmatchcase(one.rsplit('/', 1)[-1], pattern):
            return True
    return False


def _recording_findings(cfg: vocabulary.PmConfig, enabled: set[str], warn) -> None:
    """U2 — the ledger couriers are wired and the tree holds no row.

    **This rule exists because the telemetry was off for a whole milestone and
    nobody could tell**: a courier fails open by design, so its refusals go to
    a stderr nobody reads. A tree that wires nothing opted out (0.4.0/D5).
    """
    if 'U2' not in enabled:
        return
    wiring = wired_couriers(cfg.root)
    if wiring.unread:
        warn(f'{wiring.unread}, so whether the ledger couriers are '
             f'wired is UNVERIFIABLE — not a finding, and not a pass either '
             f'(U2)')
        return
    if not wiring.couriers:
        return
    wired = list(wiring.couriers)
    found, unreadable = _tree_has_a_row(cfg)
    if unreadable:
        warn(f'{", ".join(unreadable)} could not be read, so whether this tree '
             f'is recording is UNVERIFIABLE — not a finding, and not a pass '
             f'either (U2)')
        return
    if found:
        return
    warn(f'{" and ".join(wired)} {"is" if len(wired) == 1 else "are"} wired in '
         f'{wiring.where} and {cfg.roadmap_dir} holds no ledger row at '
         f'all — this tree is recording NOTHING, silently, because a courier '
         f'fails open by design. Four causes, in the order they cost people '
         f'time: the `pm` make target is not .PHONY (a PM tree IS a `pm/` '
         f'directory, so make exits 0 without reaching the verb); '
         f'`[pm.states.*]` is undeclared, so every work-moving verb refuses; '
         f'`python3` or the transcript path does not resolve; the entries name '
         f'a script that is not there. **`bash tools/hooks/'
         f'cc-ledger-session.sh --self-test` answers all four**. A fifth is '
         f'outside this tree: a session rooted elsewhere loads its own '
         f'settings file and derives its own root, which is what '
         f'`install-hooks --write-settings` and `GDK_LEDGER_ROOT` are for '
         f'(U2)')


def _hook_written(row: dict) -> bool:
    """Did a COURIER write this row?

    The kind AND a `session_id`. The kind is off `ledger.EVENT_KINDS`, the
    writer's own vocabulary — but alone it is not enough: `pm ledger record
    SubagentStop` mints exactly those kinds by hand from inside the checkout,
    and this repo counted sixteen of them as evidence a courier ran when none
    ever had. The session id comes from the hook payload; a hand row has none.
    A courier row lacking one reads as `never` — noisy, never blind.
    """
    from agentic_sdlc.repo.pm import ledger
    if _kind_of(row) not in set(ledger.EVENT_KINDS.values()):
        return False
    session = row.get('session_id')
    return isinstance(session, str) and bool(session.strip())


def _hook_recording_findings(cfg: vocabulary.PmConfig, enabled: set[str],
                             warn) -> None:
    """U4 — the couriers are wired, and the last row THEY wrote, with its age.

    **This rule was found by this build recording nothing.** Every wiring
    answer was green and U2 did not fire, because the ledgers were not empty —
    they held the rows this checkout writes itself. **No rule counted row
    KINDS**, so the one fact separating a wired path from a working one went
    unasked; the trap itself is spelled in the WARN below.

    `wired` alone is the tool asserting an outcome it did not observe (rule 4).
    A WARN, never a finding, and a tree that wires nothing stays silent
    (0.4.0/D5).
    """
    if 'U4' not in enabled:
        return
    from agentic_sdlc.repo.pm import ledger
    wiring = wired_couriers(cfg.root)
    if wiring.unread:
        warn(f'{wiring.unread}, so the last hook-written row cannot be read '
             f'beside its wiring — UNVERIFIABLE, not a finding and not a pass '
             f'either (U4)')
        return
    rec = hook_recording(cfg)
    wired = list(wiring.couriers)
    # THE OPT-OUT, and the whole of it: wires nothing AND records nothing.
    # Gating on the config alone went silent on a tree holding an hour-old
    # courier row, wired in a settings file above the repo — the topology this
    # package now ships. The ledger proves the path wherever the config is.
    if not wired and not rec.written:
        return
    if rec.unreadable:
        warn(f'{", ".join(rec.unreadable)} could not be read, so the last '
             f'hook-written row is UNVERIFIABLE — not a finding, and not a '
             f'pass either (U4)')
        return
    events = ' and '.join(sorted(ledger.EVENT_KINDS))
    kinds = '/'.join(dict.fromkeys(ledger.EVENT_KINDS.values()))
    if not rec.written:
        rows, _ = _ledger_rows(cfg)
        held = _kind_census(rows, top=CENSUS_TOP) or 'no rows at all'
        # THE FIX FIRST. It used to sit at the end of 839 characters, behind a
        # thirteen-kind census — the eleven wrapped lines this feature measured.
        warn(f'{" and ".join(wired)} {"is" if len(wired) == 1 else "are"} '
             f'wired in {wiring.where} and no {kinds} row has EVER '
             f'landed in {cfg.roadmap_dir}/ — last hook-written row: '
             f'{recording_phrase(rec)}{_recording_span(rows)}. '
             f'`{vehicle.command("install-hooks", "--write-settings")}` lands '
             f'the block here, and `GDK_LEDGER_ROOT` points a session rooted '
             f'elsewhere at this tree: whether a harness fires the {events} '
             f'hook depends on the session\'s project root, not on '
             f'{wiring.where}. The ledgers hold {held}, which this checkout '
             f'writes itself; `{vehicle.command("pm", "ledger", "report")}` '
             f'breaks them down (U4)')
        return
    # COUNTED, never a finding: the age is what tells live telemetry from
    # telemetry that stopped.
    seen = (f'wired in {wiring.where}' if wiring.where else
            f'wired in no settings file in this checkout, so the config a '
            f'harness loaded lives above it')
    print(f'  RECORDING  last hook-written row: {recording_phrase(rec)} — '
          f'{rec.written} of {rec.total} row(s) in {cfg.roadmap_dir}/ came '
          f'from a courier; {seen}  [{rec.where}] (U4)')


def _flow_findings(cfg: vocabulary.PmConfig, enabled: set[str], report) -> None:
    """D9/D10 over every `in_progress` milestone; two in progress is two answers."""
    live = (inventory.in_progress_milestones(cfg)
            if enabled & set(vocabulary.FLOW_CHECKS) else [])


    mainline = vocabulary.mainline_branch() if 'D10' in enabled and live else ''

    for mid, branch, mfile in live:
        if 'D9' in enabled and not branch:
            report(f'in-progress milestone {mid} declares no branch: — a fresh '
                   f'checkout cannot find where its work lives  [{cfg.rel(mfile)}]')
        if 'D10' in enabled:
            if not branch:
                report(f'in-progress milestone {mid} declares no branch: — D10 '
                       f'needs a branch off the mainline ({mainline!r}) to '
                       f'declare  [{cfg.rel(mfile)}]')
            elif branch == mainline:
                report(f'in-progress milestone {mid} declares branch: {branch!r}, '
                       f'the mainline itself — work must live off '
                       f'{mainline!r}, not on it (D10)  [{cfg.rel(mfile)}]')


def _changelog_answered(cfg: vocabulary.PmConfig, enabled: set[str], warn) -> None:
    """D12 — a grain in `done` that answered the changelog question neither way.

    A WARN: the release belt refuses at the rung that ships, and reddening
    every inner-loop gate over an unwritten sentence is how a surface gets
    scrolled past. `none` is an ANSWER; this names silence.

    SHIPPED MILESTONES ARE OUT OF SCOPE — not history rewriting. 168 grains
    closed before the field existed, and asking them all for a sentence nobody
    will write is 351-of-359 again.
    """
    if 'D12' not in enabled:
        return
    from agentic_sdlc.repo.pm import changelog as clog
    graded = silent = 0
    index = inventory.grain_index(cfg)
    for gid, grain in sorted(index.items()):
        if grain.kind not in vocabulary.FLOW_KINDS:
            continue
        status = grain.field(vocabulary.FIELD_STATUS)
        if vocabulary.category_of(cfg, grain.kind, status) != vocabulary.DONE_CATEGORY:
            continue
        if _shipped_parent(cfg, grain):
            continue
        graded += 1
        if grain.field(clog.FIELD).strip() or clog.answered_by_feature(index, grain):
            continue
        silent += 1
        # The sentence is FREE TEXT, so it is single-quoted at both parses:
        # a `$` or a backtick in what the operator types reaches the verb.
        warn(f'{grain.kind} {gid} is {status!r} ({vocabulary.DONE_CATEGORY}) and '
             f'carries no `{clog.FIELD}:` — '
             f'`{vehicle.command("pm", "set", gid, clog.FIELD, "<sentence>")}` '
             f'({vehicle.FREE_TEXT_NOTE}), or `{clog.NEEDS_NONE}` to say it '
             f'earned no consumer-visible line (D12)  [{cfg.rel(grain.path)}]')
    print(f'  CHANGELOG  {graded - silent} of {graded} closed grain(s) '
          f'answered, shipped milestones excluded (D12)')


def _ladder_refused(enabled: set[str], report) -> None:
    """D15: `[verify]` read by the one reader the rung verbs share (#103).

    `make check` and the hooks stayed green for a day over `milestone = "make
    parse && make lint"`; the first `dispatch` refused it at exit 2, and
    `release` would have at close. Here it is a FINDING, never this gate's
    exit 2: the ladder is wrong, and the PM tree is still readable.
    """
    if 'D15' not in enabled:
        return
    from agentic_sdlc.core.project import CONFIG_NAME
    why = vocabulary.ladder_defect()
    if why:
        # Several problems arrive as a list on several lines; a finding is one.
        said = ' '.join(part.strip() for part in why.splitlines())
        report(f'{said} — `dispatch`, `integrate` and `verify` refuse this '
               f'[verify] at exit 2 (D15)  [{CONFIG_NAME}]')


def _shipped_parent(cfg: vocabulary.PmConfig, grain) -> bool:
    """Is this grain's milestone in `done`? Followed through the bindings."""
    mid = inventory.milestone_of(cfg, grain.gid)
    if not mid:
        return False
    parent = inventory.grain_index(cfg).get(mid)
    if parent is None:
        return False
    return vocabulary.category_of(cfg, vocabulary.GRAIN_MILESTONE,
                             parent.field(vocabulary.FIELD_STATUS)
                             ) == vocabulary.DONE_CATEGORY


def _containment(cfg: vocabulary.PmConfig, enabled: set[str], report) -> None:
    """D11 — a parent in `done` over a child that is not, at every level.

    ONE walk off `BINDS_TO`; a FINDING, never a WARN, because a parent
    closing over an open child makes its own census a lie (rule 4). No opt-out
    FIELD — `fix_milestone:` was one and defaulted to opted-out, silently. The
    opt-out is the BINDING, and V7 counts what it returns to the pool. The rule
    itself is `[pm] checks`' to turn off, and ROSTER names it when it is.
    """
    if 'D11' not in enabled:
        return
    index = inventory.grain_index(cfg)
    graded = 0
    for child in sorted(index.values(), key=lambda g: g.gid):
        bind = vocabulary.BINDS_TO.get(child.kind)
        if bind is None or not child.binding:
            continue
        parent = index.get(child.binding)
        if parent is None:
            continue
        graded += 1
        p_status = parent.field(vocabulary.FIELD_STATUS)
        if vocabulary.category_of(cfg, parent.kind, p_status) != vocabulary.DONE_CATEGORY:
            continue
        c_status = child.field(vocabulary.FIELD_STATUS)
        if vocabulary.category_of(cfg, child.kind, c_status) == vocabulary.DONE_CATEGORY:
            continue
        report(f'{parent.kind} {parent.gid} is {p_status!r} '
               f'({vocabulary.DONE_CATEGORY}) but {child.kind} {child.gid} is '
               f'{c_status!r} ({_cat(cfg, child.kind, c_status)}) — a parent '
               f'does not close over an unresolved child; finish it, or '
               f'`{vehicle.command("pm", "remove", parent.gid, child.gid)}` '
               f'returns it to the pool (D11)  [{cfg.rel(child.path)}]')
    print(f'  CONTAINMENT  {graded} bound child/ren graded against their '
          f'parent (D11)')


def _retired_fields(cfg: vocabulary.PmConfig, report) -> None:
    """A retired frontmatter field on any grain — NEVER gated by `checks`.

    It rode inside D11 until #19, so a roster that dropped D11 dropped this
    too, and one consumer's PASS covered 117 `fix_milestone:` lines. Still a
    DRIFT finding at exit 1, never a config error (0.6.0 D2): a retired field
    is a fact about the tree, and exit 2 would stop every other rule running.
    """
    for gid, grain in sorted(inventory.grain_index(cfg).items()):
        # PRESENCE, not value: an empty one is the shape that gated nothing.
        for field, why in sorted(vocabulary.RETIRED_FIELDS.items()):
            if not grain.declares(field):
                continue
            report(f'{grain.kind} {gid} carries `{field}:` — {why}; delete the '
                   f'line by hand, no `pm` verb removes a field  '
                   f'[{cfg.rel(grain.path)}]')


def _omitted_stock_rules(cfg: vocabulary.PmConfig) -> None:
    """ROSTER — a declared `[pm] checks` that omits a STOCK-ON rule, which is
    `vocabulary.DEFAULT_CHECKS` and nothing else.

    A COUNTED line, never the exit code: the roster is the project's
    declaration (rule 9). But a declared list REPLACES the stock one, so a rule
    added to the stock roster in a later release, or one a retirement message
    said to remove, is off with nothing saying so — rule 11's silence. A tree
    that declares no roster runs the stock one and prints nothing here.
    """
    omitted = [c for c in vocabulary.DEFAULT_CHECKS if c not in cfg.checks]
    if omitted:
        print(f'  ROSTER  [pm] checks omits {len(omitted)} of '
              f'{len(vocabulary.DEFAULT_CHECKS)} stock-on rule(s): '
              f'{", ".join(omitted)} — none of them runs on this tree; name '
              f'one in [pm] checks to run it '
              f'(`{vehicle.command("pm", "vocabulary")}` lists every rule)')


def _unbound_rows(cfg: vocabulary.PmConfig, enabled: set[str], report, warn) -> None:
    """The unbound family one level down from R1, in both directions (V7 at the
    top of this module). COUNTED, never a finding, because a tree mid-planning
    legitimately has many and a gate that reddens on planning gets switched off.
    """
    if 'V7' not in enabled:
        return
    for kind, ids in sorted(inventory.unbound_grains(cfg).items()):
        field = vocabulary.BINDS_TO[kind][1]
        add = vehicle.command('pm', 'add', vehicle.Slot(f'<{field}-id>'), ID)
        print(f'  UNBOUND  {len(ids)} {kind}(s) name no {field}: — '
              f'{", ".join(ids)}; `{add}` binds and sequences one (V7)')
    _sequence_rows(cfg, report, warn)


def _sequence_rows(cfg: vocabulary.PmConfig, report, warn) -> None:
    """Every container's `order` against what it holds — one walk, every level."""
    index = inventory.grain_index(cfg)
    # The ROOT is R1's, not this walk's: the plan has carried its own rule and
    # its own line, and two lines for one fact is a second
    # scoreboard.
    #
    # `BINDS_TO` and NOT `[pm.contains]`: that key says what `pm add` may
    # WRITE, and reading it here let a narrowed mapping ungate the level it
    # dropped. No config narrows what an `order` says about what it holds.
    holds = {parent for parent, _field in vocabulary.BINDS_TO.values()}
    parents = [g for g in index.values()
               if g.kind in holds and g.kind != vocabulary.ROOT_KIND]
    unsequenced: dict[str, int] = {}
    for parent in sorted(parents, key=lambda g: g.gid):
        seq = inventory.sequence_census(cfg, parent, index)
        for gid in seq.dangling:
            child = index[gid]
            bind = vocabulary.BINDS_TO.get(child.kind)
            report(f'DANGLING: {parent.gid} sequences {gid} in its `order` and '
                   f'does not hold it — {gid} names '
                   + (f'{child.binding or "no " + bind[0]}' if bind
                      else 'no parent')
                   + f'; `{vehicle.command("pm", "add", parent.gid, gid)}` '
                     f'binds it, `pm remove` takes the entry out (V7)')
        for gid in seq.unverifiable:
            warn(f'UNVERIFIABLE: {parent.gid} sequences {gid} in its `order` '
                 f'and no grain in this tree declares that id — DANGLING if it '
                 f'was never written, UNVERIFIABLE if it was retired (V7)')
        for gid in seq.unsequenced:
            unsequenced[index[gid].kind] = unsequenced.get(index[gid].kind, 0) + 1
    # Rule 4: a walk that graded nothing says so, and the count is what made
    # the narrowing above invisible for as long as it lasted.
    graded = len(parents)
    if graded:
        print(f'  SEQUENCE  {graded} container(s) graded against their `order`')
    for kind, n in sorted(unsequenced.items()):
        # COUNTED: `order` is optional per container, so a child nobody has
        # placed is a decision not taken — never a finding.
        place = vehicle.command('pm', 'add', vehicle.Slot('<parent-id>'), ID)
        print(f'  UNSEQUENCED  {n} {kind}(s) are bound and in no parent\'s '
              f'`order` — `{place}` places one, at `--position N`, '
              f'`--before <id>` or `--after <id>` inside the quotes (V7)')


def _unbound_family(cfg: vocabulary.PmConfig, enabled: set[str], order: list[str],
                    report, warn) -> None:
    """R1-R4 and R6 — the plan and the tree held to each other.

    **This is THE UNBOUND FAMILY, whose first member is the milestone-to-release
    edge**, not a set of milestone-specific rules: every level has the same pair
    — a binding that names nothing, and a grain that names no binding. Naming
    the family here costs a sentence; naming it later costs a rename in every
    consumer's output that greps these lines.
    """
    claims = inventory.version_claims(cfg)
    scheduled = set(order)
    root = inventory.root_grain(cfg)

    if 'R1' in enabled and root is not None:
        # The root's half of the sequence pair, spelled here because the plan
        # is the one container a config can turn off on its own.
        seq = inventory.sequence_census(cfg, root)
        for mid in seq.unverifiable:
            # Never a failure: the row survives its milestone on purpose.
            warn(f'UNBOUND: {mid} is in '
                 f'{cfg.rel(inventory.releases_file(cfg))} `order` and no milestone '
                 f'in this tree declares that id — DANGLING if it was never '
                 f'written, UNVERIFIABLE if it was retired (R1)')
        if seq.unsequenced:
            # COUNTED, not a finding: authoring a milestone and scheduling it
            # are separate acts.
            schedule = vehicle.command('pm', 'add', root.gid,
                                       vehicle.Slot('<milestone-id>'))
            print(f'  UNSEQUENCED  {len(seq.unsequenced)} milestone(s) are on '
                  f'no plan — {", ".join(seq.unsequenced)}; `{schedule}` '
                  f'schedules one (R1)')

    if 'R2' in enabled:
        # Backlog: a named, counted line, never a finding — a healthy tree has
        # many (the same reason as `_unbound_rows`).
        backlog = [mid for _, mid in inventory.known_milestones(cfg)
                   if mid and mid not in scheduled
                   and not inventory.milestone_version(cfg, mid)]
        if backlog:
            print(f'  BACKLOG  {len(backlog)} milestone(s) declare no '
                  f'version: and are not proposed as releases — '
                  f'{", ".join(sorted(backlog))} (R2)')

    if 'R3' in enabled:
        seen: dict[str, list[str]] = {}
        for version, mid in claims:
            seen.setdefault(version, []).append(mid)
        for version, mids in seen.items():
            if len(mids) > 1:
                report(f'version: {version} is claimed by {len(mids)} '
                       f'milestones — {", ".join(sorted(mids))}; a version '
                       f'names one release, and which one ships is otherwise '
                       f'decided by whichever document was read first (R3)')

    if 'R4' in enabled and order:
        # History is a prefix. This is the invariant that makes "next = the
        # first unshipped entry" CORRECT rather than merely usual, and it is
        # what lets version_at = "start" mean anything.
        first_open = None
        for mid in order:
            if inventory.entry_is_shipped(cfg, mid):
                if first_open is not None:
                    report(f'history is not a prefix: {mid} has shipped and '
                           f'sits AFTER {first_open}, which has not — '
                           f'`{_resequence(cfg)}` re-sequences the plan (R4)')
            elif first_open is None and not inventory.entry_is_dangling(cfg, mid):
                first_open = mid

    if 'R6' in enabled:
        last = inventory.last_shipped_index(cfg)
        for i, mid in enumerate(order):
            if i > last or inventory.entry_is_shipped(cfg, mid):
                continue
            milestone = inventory.grain(cfg, mid, vocabulary.GRAIN_MILESTONE)
            if milestone is None:
                continue
            status = milestone.field(vocabulary.FIELD_STATUS)
            report(f'{mid} sits at position {i + 1}, behind the last '
                   f'shipped release, and is {status!r} — its work went out '
                   f'under someone else\'s version and the record never '
                   f'moved (R6)')
        for version, mid in claims:
            milestone = inventory.grain(cfg, mid, vocabulary.GRAIN_MILESTONE)
            status = milestone.field(vocabulary.FIELD_STATUS) if milestone else ''
            done = vocabulary.category_of(cfg, vocabulary.GRAIN_MILESTONE,
                                     status) == vocabulary.DONE_CATEGORY
            if done and mid not in scheduled:
                report(f'milestone {mid} is {status!r}, claims version '
                       f'{version} and is on no plan — a milestone that '
                       f'finished without ever being scheduled as a '
                       f'release (R6)')


def _schedule(cfg: vocabulary.PmConfig) -> str:
    """The move that puts a milestone on the plan."""
    return vehicle.command('pm', 'add', inventory.root_id(cfg),
                           vehicle.Slot('<milestone-id>'))


def _resequence(cfg: vocabulary.PmConfig) -> str:
    """The move that puts a milestone ahead of another in the plan."""
    return vehicle.command('pm', 'add', inventory.root_id(cfg),
                           vehicle.Slot('<milestone-id>'), '--before', ID)


def _release_findings(cfg: vocabulary.PmConfig, enabled: set[str], report, warn) -> None:
    """The release family. R1-R4 and R6 are in `_unbound_family`; R5, below, is
    the version file against the CURRENT release — a POSITION in `order`, never
    a parse, so it fits bump-at-start and bump-at-close both ([pm] version_at)
    and has no opinion about what a version string looks like.
    """
    if not enabled & set(vocabulary.RELEASE_CHECKS):
        return
    # A plan that is THERE and unreadable is a finding, not the absence of one:
    # "declares no `order`" over a BOM-damaged file is rule 4's first sin.
    defect = inventory.plan_defect(cfg)
    if defect is not None:
        report(f'{cfg.rel(inventory.releases_file(cfg))} {defect} — R5 cannot read '
               f'the plan, so {cfg.version_file} was NOT graded (R5)')
        return
    order = inventory.declared_order(cfg)
    _unbound_family(cfg, enabled, order, report, warn)
    if 'R5' not in enabled:
        return
    if not order:
        # A tree mid-adoption has no plan yet; a rule that fails every fresh
        # consumer gets switched off.
        warn(f'R5 is enabled and {cfg.rel(inventory.releases_file(cfg))} declares '
             f'no `order` — nothing to grade {cfg.version_file} against; '
             f'`{_schedule(cfg)}` writes the plan')
        return
    accepted, why = inventory.graded_release_accepts(cfg)
    current = accepted[0] if accepted else None
    if current is None:
        # The reason is READ, never invented: "every entry has shipped" over a
        # tree where none had was a confident wrong answer at exit 0 (B3).
        warn(f'R5 has nothing to grade {cfg.version_file} against — {why} '
             f'(under [pm] version_at = {cfg.version_at!r})')
        return
    version = inventory.shipped_version(cfg)
    if version is None:
        report(f'no version found in {cfg.version_file} — R5 cannot verify it '
               f'against the current release {current!r} (R5)')
        return
    if version in accepted:
        return
    # The file names a milestone the plan does not hold: that is the cause, and
    # the plan is what moves, not the version (#88). Still a finding.
    unplanned = [m for m in inventory.milestones_of_version(cfg, version)
                 if m not in order]
    if unplanned:
        held = inventory.grain(cfg, unplanned[0], vocabulary.GRAIN_MILESTONE)
        status = held.field(vocabulary.FIELD_STATUS) if held is not None else '?'
        add = vehicle.command('pm', 'add', inventory.root_id(cfg), unplanned[0])
        report(f'{cfg.version_file} version {version!r} is claimed by '
               f'{unplanned[0]} ({status}), which is on no plan — `{add}` (R5)')
        return
    mid = inventory.milestone_of_version(cfg, current)
    claims = (f'the milestone {mid!r} claims it'
              if mid is not None
              else 'no milestone claims it — an `order` entry nothing carries')
    named = ' or '.join(repr(v) for v in accepted)
    report(f'{cfg.version_file} version {version!r} does not match '
           f'{named} ({claims}), which is the '
           f'{"last started" if cfg.version_at == vocabulary.VERSION_AT_START else "last shipped"} '
           f'entry in {cfg.rel(inventory.releases_file(cfg))} under [pm] '
           f'version_at = {cfg.version_at!r} (R5)')


def _census(cfg: vocabulary.PmConfig, n_milestones: int, n_features: int,
            n_stories: int, n_bugs: int) -> str:
    """`'4 milestone(s), 44 feature(s), 79 story/ies, 11 bug(s)'` — with every
    narrowing each walk made, rendered beside the count it narrowed.

    Pooled counts are the POOL's rather than the drift walk's on purpose: a
    document with damaged frontmatter declares no `id:`, so no descent reaches
    it, and a census counting only what the descent saw would quietly drop the
    document `unkeyed_documents` just reported by name.
    """
    if inventory.is_pooled(cfg):
        return ', '.join(inventory.pool_census(cfg, kind, label) for kind, label in
                         ((vocabulary.GRAIN_MILESTONE, 'milestone(s)'),
                          (vocabulary.GRAIN_FEATURE, 'feature(s)'),
                          (vocabulary.GRAIN_STORY, 'story/ies'),
                          (vocabulary.GRAIN_BUG, 'bug(s)')))
    census = (f'{n_milestones} milestone(s), {n_features} feature(s), '
              f'{n_stories} story/ies')
    # `Walk` renders every narrowing itself, so a new filter discloses without an edit here.
    census += inventory.tree_walk(cfg).disclosures()
    return census + f', {n_bugs} bug(s)'


def _verdict(cfg: vocabulary.PmConfig, findings: list[str], warnings: list[str],
             census: str, v_on: set[str], v_census: dict,
             closes: str = '') -> int:
    """The census + verdict; warnings are counted separately and never decide
    the code. `closes` ends the line, PASS or FAIL: a ready close is a fact
    about the tree either way."""
    print()
    if v_census:
        census += f', {v_census["refs"]} ref(s)'
        if v_census['unverifiable']:
            census += (f' ({v_census["unverifiable"]} UNVERIFIABLE — the ref '
                       f'names a retired grain or a milestone no longer in '
                       f'the tree)')
    what = 'status-drift / integrity violation(s)' if v_on else 'status-drift violation(s)'
    warned = f'; {len(warnings)} warning(s)' if warnings else ''
    if findings:
        print(f'[check:pm] FAIL — {len(findings)} {what} across {census}'
              f'{warned}{closes}')
        return 1
    clean = 'no PM-tree drift or integrity problems' if v_on else 'no PM-tree status drift'
    print(f'[check:pm] PASS — {clean}; scanned {census}{warned}{closes}')
    return 0
