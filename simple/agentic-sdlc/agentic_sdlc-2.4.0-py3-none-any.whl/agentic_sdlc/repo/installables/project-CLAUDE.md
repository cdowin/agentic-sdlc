# CLAUDE.md

Orientation for agents working in this repo. `agentic-sdlc init` wrote this
skeleton once and never overwrites it — **it is yours**: replace every section
with what is true here. The tooling is
[agentic-sdlc](https://github.com/cdowin/agentic-sdlc), pinned in `uv.lock`
(the `dev` group of `pyproject.toml`) and configured in `devkit.toml`: `pm` writes
one status, `check` reads the same files and echoes findings, `integrate`
merges a batch and proves it once, and `release` checks facts and writes the
milestone's status or refuses; `--force` writes anyway, on the record.
`make sdlc ARGS='install-* --diff'` shows what a pin bump would change.

## What this project is

*(One paragraph: what this is, who uses it, and what it is built in.)*

## Where things live

*(The rule, not the inventory — where a new thing goes, and which suffix means
what.)*

## The ladder

**`make help` is the authoritative target list.** Every gate prints ONE verdict
line naming its transcript under `.gate-reports/`; `VERBOSE=1` streams it.
Never hand-roll an incantation, and never run a rung wider than the thing you
changed — if the check you need is not a target, add the target.

| you changed | run |
|---|---|
| the PM tree, or a doc | `make check` |
| code, inner loop | `make sdlc ARGS='verify --spot'` — what `[verify] spot` names |
| code, before a commit | `make precommit` — `check` + this project's `GDK_PRECOMMIT_TIERS` |
| closing a story | `make pm ARGS='story done <id>'` — a status write |
| integrating a batch | `make sdlc ARGS='integrate <slug>...'` — merge, prove once, close |
| closing a milestone | `make sdlc ARGS='release <version>'` — facts only; CI runs `make milestone` |
| bumping the devkit pin | `make sdlc ARGS='adopt <version>'` |

`make sdlc ARGS='verify --plan'` prints each rung with the cost it last took.
`make check` is `[checks] all` plus this project's `[gates] extra`, and boots
nothing; `precommit` and `milestone` add `GDK_PRECOMMIT_TIERS` /
`GDK_MILESTONE_TIERS` from `Makefile.tiers`.

*(List this project's tier targets here — what each runs and what it needs
installed.)*

## How we work

- **The PM tree is `pm/roadmap/`.** Status moves through the CLI, never a hand
  edit (`make pm ARGS='story building <id>'`); `make sdlc ARGS='check pm'` is the
  drift gate. The loop auto-loads from `.claude/rules/pm-execution.md`; the
  manual is `.claude/skills/pm-operations/SKILL.md`.
- **The agent roster is `.claude/agents/`.** Each file opens with a `Project
  config` section — edit it to this project's spellings.
- **The guards are armed by `tools/setup-hooks.sh`**: a git command that
  cannot be undone (a force push, `reset --hard`, `clean -f`, a whole-tree
  discard, `stash`) is refused, a write outside the agent's tree is refused,
  and a push to a protected branch is blocked. A guard never runs a gate.
- **The dispatch loop is the `run-the-sdlc` skill.** *(Your branching and
  release flow goes here.)*

## Architecture invariants

*(The cross-cutting rules every change must respect, each with a pointer to
its spec. Short enough to be read.)*

## Don'ts

- **Never hand-roll what a target already does.**
- **Never claim done without the rung that proves it.** `make precommit` on
  any runtime-affecting change; `pm story done <id>` when the story is done.
- *(Add the footguns this project has actually hit.)*
