---
id: {id}
kind: {kind}
milestone: "{milestone}"
name: {name}
status: planning
reviewed:
depends_on: []
consumed_by: []
changelog:
---

# {name}

<!-- What this feature is, and why it earns a slot in the milestone. -->

## Ship criterion

<!-- What "done" means for this feature. -->

## Proof budget

<!-- Roughly how many test cases this feature should cost, written before it is
     built and compared after. Name the tier and the existing module they land
     in; say what the suite already checks and why that is not enough. -->

  cases:
  tier:
  lands in:
  what already covers this:
