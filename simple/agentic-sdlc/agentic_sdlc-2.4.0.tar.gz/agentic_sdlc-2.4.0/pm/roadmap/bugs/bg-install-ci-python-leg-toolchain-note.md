---
id: bg-install-ci-python-leg-toolchain-note
kind: bug
milestone: ms-the-backlog-is-empty
name: install ci python leg toolchain note
status: closed
caused_by:
changelog: install-ci's next step says the python job gets none of verify's toolchain steps.
---

# install ci python leg toolchain note

## Symptom

MINOR. `repo/install.py::_NEXT_STEP['install-ci']`: it does not say the `python` job gets none of the toolchain steps added to `verify`. Source: 0.18.0-ci/W3 (issue #108; graded live at 2.3.0).

## Root cause

See the review record named in Symptom.

## Fix

Add one sentence to it.
